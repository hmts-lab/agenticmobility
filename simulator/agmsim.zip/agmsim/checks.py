"""Is a run plausible? A fixed list of checks.

``agmsim check [scenario]`` runs a scenario and holds it against three kinds of check:

* **consistency** -- what must hold in any run: every trip has one outcome, vehicles are conserved on
  every road, nobody is faster than free flow, no road holds more than fits or lets through more than
  its capacity, the same seed gives the same run;
* **response** -- how the run must answer a change (each costs one more run): with more travellers, and
  with less road, car trips must not get quicker. (That an incident makes nobody quicker is not among
  them: where vehicles re-route it need not hold.)
* **size** -- for the testbed: the survey numbers it is tuned to (:data:`agmsim.montreal.TARGETS`).

Every check is a row ``{group, check, ok, value, expected}``. The table of roads -- what drove where,
and what each road let through against what it can -- is the run's ``metrics["roads"]``.
"""
from __future__ import annotations

from .config import TESTBED
from .entities import TState

SLACK = 0.02            # a response may fall short by this much of the base value before it counts as wrong


def measures(sim) -> dict:
    """The sizes that surveys also report, read off a finished run."""
    w, dt = sim.world, sim.dt
    people = [t for t in w.travelers.values() if t.plan is None]
    done = [t for t in people if t.state == TState.ARRIVED]
    if not done:
        return {}
    share = lambda *modes: sum(1 for t in done if t.mode in modes) / len(done)      # noqa: E731
    cars = [t for t in done if t.mode == "car"]
    car_s = sum((t.t_arrival - t.t_need) * dt for t in cars)
    out = {"trip_minutes": sum((t.t_arrival - t.t_need) * dt for t in done) / len(done) / 60.0,
           "car_share": share("car", "car+bus"), "transit_share": share("bus"), "ondemand_share": share("ride"),
           "before_9_share": sum(1 for t in people if w.clock0 + t.t_need * dt < 9 * 3600) / len(people)}
    if car_s:
        out["car_speed_kmh"] = sum(t.trip_m for t in cars) / car_s * 3.6
    return out


def _row(group: str, check: str, ok: bool, value, expected: str) -> dict:
    return {"group": group, "check": check, "ok": bool(ok), "value": value, "expected": expected}


def consistency(sim, result) -> list:
    """What must hold in any run."""
    w, net, m, dt = sim.world, sim.world.net, result.metrics, sim.dt
    rows = []
    tr = m.get("travelers")
    if tr:
        rows.append(_row("consistency", "every trip has exactly one outcome",
                         tr["completed"] + tr["abandoned"] + tr["unfinished"] == tr["trips"],
                         f"{tr['completed']} + {tr['abandoned']} + {tr['unfinished']} of {tr['trips']}",
                         "completed + abandoned + unfinished = trips"))
        shares = sum(tr["mode_share"].values()) if tr["mode_share"] else 1.0
        rows.append(_row("consistency", "the shares of the ways of travelling add up to 1", abs(shares - 1.0) < 1e-3,
                         round(shares, 4), "1"))
    movers = [x for group in (w.vehicles, w.cabs, w.buses) for x in group.values()]
    on = {}
    for x in movers:
        if x.link is not None:
            on[x.link] = on.get(x.link, 0) + 1
    off = [link.id for link in net.links if net.entered[link.id] - net.left[link.id] != on.get(link.id, 0)]
    rows.append(_row("consistency", "vehicles are conserved on every road", not off,
                     f"{sum(net.entered)} drove on, {sum(net.left)} drove off, {sum(on.values())} still on a road"
                     + (f"; wrong on {len(off)} roads" if off else ""), "drove on - drove off = still on it, road by road"))
    slow = [v.id for v in w.vehicles.values() if v.drive_s_owner < v.free_s_owner - dt * max(1, v.trips)]
    rows.append(_row("consistency", "no car is faster than free flow", not slow,
                     f"car time / free-flow time = {m['vehicles']['travel_time_ratio']}" if "vehicles" in m else "no cars",
                     "every car's time on its trips >= their free-flow time"))
    o = m["outcomes"]
    if o["traffic_speed_kmh"] is not None:
        top = max(link.speed for link in net.links) * 3.6
        rows.append(_row("consistency", "traffic moves between a crawl and free flow", 3.0 < o["traffic_speed_kmh"] <= top + 1e-6,
                         f"{o['traffic_speed_kmh']} km/h", f"3 to {top:.0f} km/h (the fastest road)"))
    traffic = net.traffic
    if traffic is not None:
        over = [i for i in range(len(net.links)) if traffic.occ_max[i] > max(traffic.slots[i], 2.0) + traffic.forced[i] * 2 + 1e-6]
        worst = max(range(len(net.links)), key=lambda i: traffic.occ_max[i] / traffic.slots[i])
        rows.append(_row("consistency", "no road holds more than fits on it", not over,
                         f"fullest: {traffic.occ_max[worst]:.0f} of {traffic.slots[worst]:.0f} "
                         f"({net.road_names.get((net.links[worst].u, net.links[worst].v), worst)})",
                         "most at once <= what fits (vehicles let in after stuck_seconds aside)"))
        ratio = [(max((c[i] for c in traffic.through.values()), default=0), traffic.gates[i].rate * 3600.0, i)
                 for i in range(len(net.links))]
        fast = [(n, cap, i) for n, cap, i in ratio if n > cap + 2.0]
        n, cap, i = max(ratio, key=lambda r: r[0] / r[1])
        rows.append(_row("consistency", "no road lets through more than its capacity", not fast,
                         f"busiest: {n} in an hour, capacity {cap:.1f} ({net.road_names.get((net.links[i].u, net.links[i].v), i)})",
                         "let through in any hour <= capacity (+2: one saved up, one rounding)"))
        left = sum(len(g.queue) for g in traffic.gates)
        rows.append(_row("consistency", "the books of the queues balance",
                         abs(sum(traffic.occ) - sum(traffic.load.values())) < 1e-6 and left == sum(1 for x in movers if x.queued),
                         f"{sum(traffic.occ):.0f} on roads, {left} in line", "room taken = room held by vehicles; in line = marked as waiting"))
        rows.append(_row("consistency", "no vehicle had to be let onto a full road", sum(traffic.forced) == 0,
                         sum(traffic.forced), "0 (more means the run leans on stuck_seconds)"))
    cars = [(t, (t.t_arrival - t.t_need) * dt / (t.trip_s + sim.cfg.agents.vehicle.terminal_seconds))
            for t in w.travelers.values() if t.state == TState.ARRIVED and t.mode == "car" and t.plan is None and t.trip_s > 0]
    hours = {}
    for t, ratio_ in cars:
        hours.setdefault(int(t.t_need * dt // 3600), []).append(ratio_)
    hours = {h: v for h, v in hours.items() if len(v) >= 10}
    if len(hours) >= 2:
        busy, quiet = max(hours, key=lambda h: len(hours[h])), min(hours, key=lambda h: len(hours[h]))
        rb, rq = sum(hours[busy]) / len(hours[busy]), sum(hours[quiet]) / len(hours[quiet])
        rows.append(_row("consistency", "car trips in the busiest hour are no quicker than in the quietest", rb >= rq - SLACK,
                         f"time / free-flow time {rb:.2f} (hour {busy}, {len(hours[busy])} trips) against {rq:.2f} "
                         f"(hour {quiet}, {len(hours[quiet])} trips)", "busiest >= quietest"))
    return rows


def size(sim) -> list:
    """The testbed against the survey numbers it is tuned to."""
    from .montreal import TARGETS
    got = measures(sim)
    rows = []
    for key, what, target, (low, high), unit, source, _url in TARGETS:
        if key not in got:
            continue
        value = got[key]
        shown = f"{value:.1f} {unit}" if unit != "share" else f"{100 * value:.1f}%"
        band = f"{low:g} to {high:g} {unit}" if unit != "share" else f"{100 * low:g}% to {100 * high:g}%"
        aim = f"{target:g} {unit}" if unit != "share" else f"{100 * target:g}%"
        rows.append(_row("size", what, low <= value <= high, shown, f"{aim} (accepted: {band}). {source}"))
    return rows


def check(scenario: str = TESTBED, overrides=(), responses: bool = True, progress=None) -> dict:
    """Run ``scenario`` and check it. Returns ``{"ok", "rows", "roads", "traffic", "metrics"}``."""
    from .engine import Simulation

    overrides = ["record.dir=null", *overrides]

    def run(extra=()):
        sim = Simulation(scenario, overrides=[*overrides, *extra])
        return sim, sim.run()

    def say(text):
        if progress is not None:
            progress(text)

    say("the run")
    sim, base = run()
    rows = consistency(sim, base)
    say("the same run again")
    _, again = run()
    rows.append(_row("consistency", "the same seed gives the same run", again.trace_digest == base.trace_digest,
                     base.trace_digest, "the same fingerprint twice"))
    if responses and "vehicles" in base.metrics:
        cfg = sim.cfg
        ratio = lambda r: r.metrics["vehicles"]["travel_time_ratio"]      # noqa: E731
        changes = [("with a quarter more travellers car trips are no quicker",
                    [f"agents.traveler.count={int(round(cfg.agents.traveler.count * 1.25))}"]),
                   ("with a quarter less road capacity car trips are no quicker",
                    [f"network.capacity_scale={cfg.network.capacity_scale * 0.75}"])]
        for what, change in changes:
            say(what)
            _, other = run(change)
            a, b = ratio(base), ratio(other)
            rows.append(_row("response", what, b >= a - SLACK, f"time / free-flow time {a:.3f} -> {b:.3f}", "not lower"))
    if sim.cfg.network.type == "montreal":
        rows += size(sim)
    return {"ok": all(r["ok"] for r in rows), "rows": rows, "roads": base.metrics["roads"],
            "traffic": base.metrics["traffic"], "metrics": base.metrics}


def format_rows(rows: list) -> str:
    lines, group = [], None
    for r in rows:
        if r["group"] != group:
            group = r["group"]
            lines.append(f"{group}")
        lines.append(f"  {'ok  ' if r['ok'] else 'FAIL'}  {r['check']}: {r['value']}")
        lines.append(f"        expected: {r['expected']}")
    return "\n".join(lines)


def format_roads(roads: list, top: int = 12) -> str:
    """The busiest roads, one line each."""
    rows = sorted(roads, key=lambda r: -r["vehicles"])[:top]
    lines = [f"  {'road':<30} {'from':>4} {'to':>3} {'vehicles':>8} {'busiest hour':>12} {'of capacity':>11} {'queue':>5} {'spillback s':>11}"]
    for r in rows:
        lines.append(f"  {(r['road'] or '-'):<30} {r['from']:>4} {r['to']:>3} {r['vehicles']:>8} "
                     f"{r.get('let_through_busiest_hour', r['busiest_hour']):>12} "
                     f"{r.get('busiest_hour_of_capacity', ''):>11} {r.get('queue_max', ''):>5} {r.get('spillback_s', ''):>11}")
    return "\n".join(lines)
