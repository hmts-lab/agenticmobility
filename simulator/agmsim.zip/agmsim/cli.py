"""Command-line interface: ``agmsim run | check | record | traffic | network | matrix | replay | explain | prompt | list | serve``."""
from __future__ import annotations

import argparse
import json
import sys

from .config import ConfigError, list_scenarios
from .llm import LLMError


def _print_summary(metrics: dict) -> None:
    def line(title, d, keys):
        parts = [f"{k}={d[k]}" for k in keys if k in d and d[k] is not None]
        if parts:
            print(f"  {title:<10} " + "  ".join(parts))

    if "travelers" in metrics:
        line("travellers", metrics["travelers"], ["trips", "completion_rate", "mode_share", "trip_time_s_mean",
                                                 "generalised_cost_usd_mean", "gave_up_waiting"])
    for name, keys in (("outcomes", ["wait_time_s_mean", "vmt_miles", "vht_hours", "traffic_speed_mph"]),
                       ("plans", ["people", "completed", "score_usd_mean", "people_late", "late_min_mean",
                                  "activities_skipped", "reviews", "edits", "review_sensitivity"]),
                       ("vehicles", ["trips", "vkt_km", "travel_time_ratio", "reroutes", "suggestions",
                                     "suggestions_accepted", "charge_stops", "tolls_usd"]),
                       ("bus", ["boardings", "holds", "stops_skipped", "left_behind"]),
                       ("evcs", ["sessions", "energy_kwh", "revenue_usd", "utilisation"]),
                       ("operator", ["advisories_published", "bus_priority_time_share", "toll_usd_final",
                                     "toll_revenue_usd"])):
        if name in metrics:
            line(name, metrics[name], keys)
    print("  decisions  " + "  ".join(
        f"{k}[{d['agency_level']},{d['policy']}]: asked {d['decided']}, default-by-rule {d['forced']}, "
        f"used authority {d['exercised']}" for k, d in metrics["decisions"].items()))
    llm = metrics["llm"]
    if llm["calls"] or llm["replayed"]:
        backends = ", ".join(f"{b['backend']}:{b['model'] or '-'}" for b in llm["backends"])
        print(f"  llm        calls={llm['calls']} replayed={llm['replayed']} tokens={llm['input_tokens']}/{llm['output_tokens']} "
              f"fallbacks={llm['fallbacks']} cost_usd={llm['cost_usd']} waited={llm['deciding_wall_s']}s [{backends}]")
        if any(b["backend"] == "mock" for b in llm["backends"]):
            print("             note: the mock backend is an offline stand-in, not a language model")


def cmd_run(args) -> int:
    from .engine import Simulation
    sim = Simulation(args.config, overrides=args.set)
    kinds = ", ".join(f"{name}×{sum(1 for s in sim.specs.values() if s.kind == name)}" for name in sim.kinds)
    print(f"{sim.cfg.name}: {kinds}; {sim.n_ticks} ticks of {sim.dt:g} s; seed {sim.cfg.simulation.seed}")

    def progress(tick, total):
        if not args.quiet and tick % max(1, total // 20) == 0:
            print(f"\r  {100 * tick // total:3d}%", end="", flush=True)

    result = sim.run(progress)
    if not args.quiet:
        print("\r", end="")
    _print_summary(result.metrics)
    print(f"  trace digest {result.trace_digest}" + (f"   saved to {result.run_dir}" if result.run_dir else ""))
    if args.json:
        print(json.dumps(result.metrics, indent=2))
    return 0


def cmd_matrix(args) -> int:
    from .experiment import LLM_2X2, format_table, run_matrix
    factors = {}
    if args.llm_2x2:
        factors.update(LLM_2X2)
    for item in args.factor or []:
        key, sep, values = item.partition("=")
        if not sep:
            raise ConfigError(f"--factor '{item}' must look like key.path=v1,v2,...")
        import yaml
        factors[key.strip()] = [yaml.safe_load(v) for v in values.split(",")]
    if not factors:
        raise ConfigError("give at least one --factor key=v1,v2 or use --llm-2x2")
    seeds = list(range(args.seed0, args.seed0 + args.seeds))

    def progress(done, total):
        print(f"\r  {done}/{total} runs", end="", flush=True)

    out = run_matrix(args.config, factors, seeds, overrides=args.set, workers=args.workers,
                     out_dir=args.out, progress=progress)
    print("\r" + format_table(out["summary"], args.metric or None))
    if args.out:
        print(f"saved to {args.out}/runs.csv and summary.json")
    return 0


def cmd_replay(args) -> int:
    from .replay import replay
    report = replay(args.run)
    print(json.dumps(report, indent=2))
    return 0 if report["identical"] else 1


def cmd_explain(args) -> int:
    """Print the decision history of one agent from a trace."""
    from .recorder import read_trace
    shown = 0
    for rec in read_trace(args.run):
        if rec["type"] != "decision" or rec["agent"] != args.agent:
            continue
        d = rec["decision"]
        tag = "no authority -> default" if rec["source"] == "forced" else rec["source"]
        print(f"tick {rec['tick']:>5}  {rec['trigger']:<10} {d['action']} {json.dumps(d.get('args') or {})}  [{tag}]")
        if rec.get("permitted"):
            print(f"            permitted: {', '.join(rec['permitted'])}")
        for key in ("rationale",):
            if d.get(key):
                print(f"            rationale: {d[key]}")
        for key in ("error", "result", "note"):
            if rec.get(key):
                print(f"            {key}: {rec[key]}")
        if args.observations and rec.get("obs"):
            print("            context: " + json.dumps(rec["obs"]["context"], ensure_ascii=False))
        shown += 1
    if not shown:
        print(f"no decisions recorded for agent '{args.agent}'")
    return 0


def cmd_prompt(args) -> int:
    """Print what a language model is told for one kind of agent, or for every kind of the scenario."""
    from .prompts import told
    kinds = told(args.config, args.set)
    if args.kind and args.kind not in kinds:
        raise ValueError(f"the scenario has no '{args.kind}'; its kinds of agent: {', '.join(kinds)}")
    for name, info in kinds.items():
        if args.kind in (None, name):
            print(f"===== {name} =====")
            print(f"goal: {info['goal'] or '(none: the kind states no objective)'}")
            print(info["system"] if info["system"] is not None else
                  f"(decided by the policy '{info['llm_policy']}', which writes its own prompt)")
            print()
    return 0


def cmd_check(args) -> int:
    """Run a scenario and hold it against the plausibility checks (and, for the testbed, the survey numbers)."""
    import csv

    from .checks import check, format_roads, format_rows
    out = check(args.config, args.set, responses=not args.quick,
                progress=None if args.quiet else lambda text: print(f"  running: {text}", flush=True))
    print(format_rows(out["rows"]))
    print(f"traffic: {out['traffic']}")
    print("the busiest roads (simulated vehicles; all roads with --roads FILE):")
    print(format_roads(out["roads"]))
    if args.roads:
        first = ["road", "from", "to"]
        keys = first + sorted({k for row in out["roads"] for k in row} - set(first))
        with open(args.roads, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=keys)
            writer.writeheader()
            writer.writerows(out["roads"])
        print(f"roads written to {args.roads}")
    failed = [r for r in out["rows"] if not r["ok"]]
    print(f"{len(out['rows']) - len(failed)} of {len(out['rows'])} checks hold" + ("" if not failed else
          ": " + "; ".join(r["check"] for r in failed)))
    return 0 if not failed else 1


def cmd_record(args) -> int:
    """Decision records: write those of a run, read those of a cabin ride, put a rider's choice into a run."""
    from pathlib import Path

    from . import record

    if args.what == "export":
        records = record.from_trace(args.run)
        out = Path(args.out) if args.out else Path(args.run) / "decisions.jsonl"
        with open(out, "w", encoding="utf-8") as fh:
            for item in records:
                fh.write(json.dumps(item, ensure_ascii=False) + "\n")
        print(f"{len(records)} decision records written to {out}")
        if args.inside and not args.situations:
            raise ConfigError("--inside goes with --situations DIR")
        if args.situations:
            folder = Path(args.situations)
            folder.mkdir(parents=True, exist_ok=True)
            inside = None
            if args.inside:                     # only the decision points at the node whose inside the tables describe
                from . import gmns
                inside = gmns.read(args.inside)[1]
                if inside is None:
                    raise ConfigError(f"{args.inside} does not describe the inside of a node (no nodes with a parent_node_id)")
            every = record.situations(args.run, inside=inside)
            chosen = record.situations(args.run, limit=args.limit, inside=inside)
            for item in chosen:
                (folder / (item["id"].replace("/", "_") + ".json")).write_text(
                    json.dumps(item, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
            kinds = {}
            for item in every:
                kinds[item["cabin"]["title"]] = kinds.get(item["cabin"]["title"], 0) + 1
            where = "" if inside is None else f" at node {inside.node}, as rides through '{inside.name}'"
            print(f"{len(every)} of them can be shown in the cabin{where} ("
                  + ", ".join(f"{n} as '{title}'" for title, n in sorted(kinds.items())) + ")")
            if inside is not None and not every:
                print("  (none: a decision point can be placed only if its routes say which junctions they pass; "
                      "run with --set agents.vehicle.observation.route_roads=true)")
            print(f"the {len(chosen)} with most at stake (up to {args.limit} of each scene) written to {folder}/")
            for item in chosen:
                a, b = item["cabin"]["options"]
                ride = ""
                if "journey" in item["cabin"]:
                    ride = (f"; ride from {item['cabin']['journey']['origin']} to {a['journey']['stops'][0]}"
                            + ("" if a["journey"] == b["journey"] else f", or to {b['journey']['stops'][0]}"))
                print(f"  {item['id']}: {a['label']} ({a['minutes']:g} min) or {b['label']} ({b['minutes']:g} min){ride}")
        return 0
    if args.what == "read":
        records = record.read_cabin(args.session, args.situation)
        text = "\n".join(json.dumps(item, ensure_ascii=False) for item in records)
        if args.out:
            Path(args.out).write_text(text + "\n", encoding="utf-8")
            print(f"{len(records)} decision records written to {args.out}")
        for item in records:
            chose = item["chose"]
            note = f"[not a rider: {item['who']['stand_in']}] " if item["who"].get("stand_in") else ""
            first = f"{item['id']}: {note}{item['trigger']['why']} at {item['who']['level']}"
            choice = (f"chose option {chose['option']} '{chose['label']}' ({chose['how']})"
                      if "option" in chose else chose["by"])
            if item["outcome"].get("traffic"):
                late = item["outcome"]["late_choices"]
                if "option" not in chose and not late and item["approval"]["by"] is not None:
                    choice = "the rider was asked and did not answer"
                carried = item["outcome"]["carried_out"]
                attempts = [f"Option {a['option']} '{a['label']}' came too late at {a['route_seconds']:g} s" for a in late]
                execution = (f"Carried out option {carried['option']} '{carried['label']}' in slot {carried['slot']} "
                             f"(release at {carried['slot_time']:g} s)")
                print(". ".join((first, choice[:1].upper() + choice[1:], *attempts, execution)) + ".")
            else:
                print(f"{first}; {choice}"
                      + (f"; in the simulation that is {json.dumps(chose['answer'])} at {item['about']}" if "answer" in chose else ""))
        return 0
    with open(args.records, encoding="utf-8") as fh:
        records = [json.loads(line) for line in fh if line.strip()]
    out = record.apply(args.run, records)
    traffic_points = {item.get("about") for item in records if item.get("outcome", {}).get("traffic")}
    for point in out["points"]:
        before, after = point["before"], point["after"]
        print(f"{point['agent']} at tick {point['tick']}:")
        carried = before is not None and before["id"] in traffic_points
        after_label = "with the action carried out in the cabin" if carried else "with the choice made in the cabin"
        for label, item in (("as it was", before), (after_label, after)):
            if item is None:
                print(f"  {label}: no such decision point in the run")
                continue
            chose = item["chose"]
            trip = item["outcome"].get("trip")
            print(f"  {label}: {chose['action']} {json.dumps(chose['args'])} [{chose['by']}]"
                  + (" -- not usable, the default applied" if "unusable" in chose else "")
                  + (f"; arrived {trip['arrived']}, {trip['minutes_after_this_decision']:g} min later" if trip else ""))
    return 0


def cmd_traffic(args) -> int:
    from pathlib import Path

    if args.what == "check":
        from .traffic_check import check_recording_size, check_traffic

        data = Path(args.file).read_bytes()
        check_recording_size(len(data))
        check_traffic(json.loads(data.decode("utf-8")))
        print(f"Traffic recording passed: {args.file}")
    else:
        from .traffic_export import export_traffic

        path = Path(args.situation)
        out = Path(args.out) if args.out else path.with_suffix(".traffic.json")
        result = export_traffic(args.run, path, args.inside, out,
                                onward_delay=args.onward_delay, decision_seconds=args.decision_seconds,
                                decision_step=args.decision_step, rate=args.rate)
        print(f"{len(result['rides'])} rides written to {out} ({out.stat().st_size:,} bytes)")
    return 0


def cmd_network(args) -> int:
    """Write a scenario's road network as GMNS tables, with a small network as the inside of one node if asked."""
    from . import gmns
    from .config import Config
    from .network import build_network

    cfg = Config.load(args.config, args.set)
    net = build_network(cfg.network, getattr(cfg, "base_dir", None))
    inside = None
    if args.inside:
        if "=" not in args.inside:
            raise ConfigError("--inside takes NODE=LAYOUT: a node (its id or its name) and the cabin's city-layout.json")
        which, layout = args.inside.split("=", 1)
        named = {name.lower(): node for node, name in net.names.items()}
        node = int(which) if which.lstrip("-").isdigit() else named.get(which.lower())
        if node not in net.nodes:
            raise ConfigError(f"the network has no node '{which}'")
        inside = gmns.Inside.from_cabin_layout(net, node, gmns.cabin_layout(layout))
    name = args.name or (cfg.name if inside is None else f"{cfg.name}-{net.names.get(inside.node, inside.node)}".lower())
    folder = gmns.write(net, args.folder, name, inside)
    print(f"{len(net.nodes)} nodes and {len(net.links)} one-way links written to {folder}/ as GMNS tables")
    if inside is not None:
        print(f"node {inside.node} ({net.names.get(inside.node, '')}) has '{inside.name}' inside: "
              f"{len(inside.nodes)} nodes, {len(inside.links)} streets, {len(inside.places)} places")
        for neighbour, gateway in sorted(inside.gateways.items()):
            road = net.road_names.get((inside.node, neighbour), "")
            print(f"  the road to {net.names.get(neighbour, neighbour)}{' (' + road + ')' if road else ''} enters at {gateway}")
    return 0


def cmd_list(args) -> int:
    from . import kinds as _k, policies as _p  # noqa: F401
    from .agency import LEVEL_NAMES
    from .demand import DEMANDS
    from .kinds.base import KINDS
    from .llm import LLM_BACKENDS
    from .network import NETWORKS
    from .policies.base import available_policies
    print("scenarios:   " + ", ".join(list_scenarios()))
    print("networks:    " + ", ".join(NETWORKS.names()))
    print("demand:      " + ", ".join(DEMANDS.names()))
    print("llm backends: " + ", ".join(LLM_BACKENDS.names()))
    from .config import LLM_PRESETS
    print("llm presets:  " + ", ".join(f"{name} ({p.get('model') or p['backend']})" for name, p in LLM_PRESETS.items()))
    print("agency levels: " + "; ".join(f"{k} {v}" for k, v in LEVEL_NAMES.items()))
    for name in KINDS.names():
        kind = KINDS.get(name)
        print(f"\n{name} ({kind.title}; {kind.side})")
        print("  policies:    " + ", ".join(available_policies(name)))
        for level in sorted(kind.agency.levels):
            print(f"  {level}: " + (", ".join(kind.agency.levels[level]) or "(no authority: default actions only)"))
    return 0


def cmd_serve(args) -> int:
    from .server import serve
    serve(args.host, args.port)
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="agmsim", description="AgMSim: agentic mobility simulator")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("run", help="run one simulation")
    p.add_argument("config", help="YAML file or packaged scenario name")
    p.add_argument("--set", action="append", default=[], metavar="KEY=VALUE", help="override a config value")
    p.add_argument("--json", action="store_true", help="print all metrics as JSON")
    p.add_argument("--quiet", action="store_true")
    p.set_defaults(fn=cmd_run)

    p = sub.add_parser("matrix", help="run a factorial experiment over seeds")
    p.add_argument("config")
    p.add_argument("--factor", action="append", metavar="KEY=V1,V2", help="factor and its levels (repeatable)")
    p.add_argument("--llm-2x2", action="store_true", help="add the human x machine LLM switch as factors")
    p.add_argument("--seeds", type=int, default=5)
    p.add_argument("--seed0", type=int, default=1)
    p.add_argument("--set", action="append", default=[], metavar="KEY=VALUE")
    p.add_argument("--metric", action="append", help="metric to show (repeatable)")
    p.add_argument("--workers", type=int, default=1)
    p.add_argument("--out", help="directory for runs.csv and summary.json")
    p.set_defaults(fn=cmd_matrix)

    p = sub.add_parser("replay", help="re-execute a recorded run from its decisions and verify it")
    p.add_argument("run", help="run directory")
    p.set_defaults(fn=cmd_replay)

    p = sub.add_parser("explain", help="show why an agent did what it did")
    p.add_argument("run")
    p.add_argument("agent")
    p.add_argument("--observations", action="store_true", help="also print what the agent saw")
    p.set_defaults(fn=cmd_explain)

    p = sub.add_parser("prompt", help="show what a language model is told for a kind of agent")
    p.add_argument("config", help="YAML file or packaged scenario name")
    p.add_argument("kind", nargs="?", help="one kind of agent (default: every kind of the scenario)")
    p.add_argument("--set", action="append", default=[], metavar="KEY=VALUE", help="override a config value")
    p.set_defaults(fn=cmd_prompt)

    p = sub.add_parser("check", help="run a scenario and check that it is plausible (the testbed: against survey numbers)")
    p.add_argument("config", nargs="?", default="montreal", help="YAML file or packaged scenario name (default: the testbed)")
    p.add_argument("--set", action="append", default=[], metavar="KEY=VALUE", help="override a config value")
    p.add_argument("--quick", action="store_true", help="leave out the checks that need further runs")
    p.add_argument("--roads", metavar="FILE", help="write the table of roads as CSV")
    p.add_argument("--quiet", action="store_true")
    p.set_defaults(fn=cmd_check)

    p = sub.add_parser("record", help="decision records: of a run, of a cabin ride, and a rider's choice put into a run")
    what = p.add_subparsers(dest="what", required=True)
    q = what.add_parser("export", help="write every decision of a recorded run as a decision record")
    q.add_argument("run", help="run directory (run with --set record.observations=all to keep what agents saw at default decisions)")
    q.add_argument("--out", help="file for the records, one JSON object per line (default: <run>/decisions.jsonl)")
    q.add_argument("--situations", metavar="DIR", help="also write the decision points the cabin can show, one file each")
    q.add_argument("--limit", type=int, default=10, help="how many situations to write of each of the cabin's scenes: those with most at stake (default 10)")
    q.add_argument("--inside", metavar="DIR", help="GMNS tables in which the cabin's city is the inside of a node (agmsim network export --inside): "
                   "only the decision points at that node, each with the ride through the cabin's city it is part of")
    q = what.add_parser("read", help="read the decision points of a ride recorded by the cabin (AgV Lab)")
    q.add_argument("session", help="the cabin's session directory (metadata.json, events.ndjson or events.csv, situation.json)")
    q.add_argument("--situation", metavar="FILE", help="the situation the ride was run on (the one kept in the session folder is used; this one is checked against it)")
    q.add_argument("--out", help="file for the records, one JSON object per line")
    q = what.add_parser("apply", help="run a recorded run again with riders' choices in place of the agents'")
    q.add_argument("run", help="run directory")
    q.add_argument("records", help="decision records read from the cabin, one JSON object per line")
    p.set_defaults(fn=cmd_record)

    p = sub.add_parser("traffic", help="offline traffic recordings for the cabin (AgV Lab)")
    what = p.add_subparsers(dest="what", required=True)
    q = what.add_parser("export", help="simulate one cabin situation in SUMO using traffic from the recorded run")
    q.add_argument("run", help="recorded AgMSim run directory")
    q.add_argument("situation", help="the situation JSON file exported from the run")
    q.add_argument("--inside", required=True, metavar="DIR", help="GMNS tables for the cabin's district")
    q.add_argument("--out", metavar="FILE", help="traffic filename (default: <situation>.traffic.json)")
    q.add_argument("--onward-delay", type=float, default=0.0, metavar="SHARE",
                   help="share of downstream city route delay represented at the gateway (default: 0)")
    q.add_argument("--decision-seconds", type=float, default=30.0, metavar="SECONDS",
                   help="time from the question to the scheduled last choice deadline (default: 30; 0 for one slot)")
    q.add_argument("--decision-step", type=float, default=10.0, metavar="SECONDS",
                   help="spacing between choice slots (default: 10)")
    q.add_argument("--rate", type=int, choices=(5, 10), default=5,
                   help="samples per second for surrounding vehicles (default: 5)")
    q = what.add_parser("check", help="validate a cabin traffic recording")
    q.add_argument("file", help="traffic recording JSON file")
    p.set_defaults(fn=cmd_traffic)

    p = sub.add_parser("network", help="a scenario's road network as GMNS tables")
    what = p.add_subparsers(dest="what", required=True)
    q = what.add_parser("export", help="write the network as node.csv, link.csv and config.csv (GMNS)")
    q.add_argument("config", help="scenario name or YAML file")
    q.add_argument("folder", help="where to write the tables")
    q.add_argument("--set", action="append", default=[], metavar="KEY=VALUE")
    q.add_argument("--name", help="dataset name (default: the scenario's, with the node's if --inside)")
    q.add_argument("--inside", metavar="NODE=LAYOUT", help="describe the cabin's small city (AgV Lab's city-layout.json) as the inside of "
                   "this node: its streets and places, and where each road that meets the node enters them")
    p.set_defaults(fn=cmd_network)

    p = sub.add_parser("list", help="list scenarios, agent kinds, agency levels and plugins")
    p.set_defaults(fn=cmd_list)

    p = sub.add_parser("serve", help="start the web interface")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8765)
    p.set_defaults(fn=cmd_serve)

    args = parser.parse_args(argv)
    try:
        return args.fn(args)
    except (ConfigError, LLMError, KeyError, ValueError, FileNotFoundError) as exc:
        print(f"error: {exc.args[0] if exc.args else exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
