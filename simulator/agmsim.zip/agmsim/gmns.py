"""Networks as GMNS tables, and a small network as the inside of one node.

GMNS (the General Modeling Network Specification, https://github.com/zephyr-data-specs/GMNS) describes a
network as tables: ``node.csv``, ``link.csv``, ``location.csv`` and ``config.csv``. :func:`write` puts a
network into that form and :func:`read` builds it again, to the same network: ``network: {type: gmns,
params: {path: <folder>}}`` runs a scenario on one.

A node of the network may stand for a whole district. :class:`Inside` is a small network that says what is
inside such a node: its streets, its places, and for every road that meets the node the point where that
road enters the streets (a gateway). In the tables its nodes carry ``parent_node_id`` (GMNS's own field for
a node that belongs to another) and, as ``zone_id``, the name of the small network; the roads that meet the
node carry where they enter in a column of their own, ``inner_node_id``. With it a trip that passes the node can be told as a ride through the streets
inside: in by one gateway, out by another, or to a place there. The cabin simulator (AgV Lab) is such an
inside: its small city, read from its layout file by :meth:`Inside.from_cabin_layout`.

Columns that are not GMNS's own: ``inner_node_id`` in ``link.csv``; ``name`` and ``role`` in
``location.csv`` (what a place is called, and what trips use it for: ``arrivals``, ``departures``,
``charging``, ``transit``); ``origin_lat`` and ``origin_lon`` in ``config.csv`` (the point local metres are
measured from, so that a network read back has its nodes where they were, to the last digit).
"""
from __future__ import annotations

import csv
import itertools
import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .network import RoadNetwork, metres_from, register_network

VERSION = 0.96                         # the version of the GMNS specification these tables follow
CONFIG = ["dataset_name", "short_length", "long_length", "speed", "crs", "geometry_field_format", "currency",
          "version_number", "id_type", "origin_lat", "origin_lon"]
NODE = ["node_id", "name", "x_coord", "y_coord", "node_type", "zone_id", "parent_node_id"]
LINK = ["link_id", "name", "from_node_id", "to_node_id", "directed", "length", "facility_type", "capacity",
        "free_speed", "lanes", "inner_node_id"]
LOCATION = ["loc_id", "link_id", "ref_node_id", "lr", "x_coord", "y_coord", "loc_type", "zone_id", "name", "role"]

#: What a trip uses a place for, by the kind of place (as the cabin's layout names its places).
ROLES = {"office": "arrivals", "residence": "departures", "charger": "charging", "station": "transit"}


@dataclass
class Inside:
    """A small network as the inside of one node of a larger one (east and north in metres from that node)."""

    node: int                                   # the node it is the inside of
    name: str = ""
    nodes: dict = field(default_factory=dict)   # id -> (east, north, type: "intersection" | "midblock")
    links: list = field(default_factory=list)   # (id, from, to, length in metres): two-way streets
    places: dict = field(default_factory=dict)  # id -> {"node", "east", "north", "type", "name", "role"}
    gateways: dict = field(default_factory=dict)   # neighbouring node of the larger network -> node here
    names: dict = field(default_factory=dict)   # node here -> what it is called (a gateway: its road and where that leads)

    def place(self, role: str) -> Optional[str]:
        """The place trips use for ``role`` (the first by id, if several)."""
        return min((pid for pid, p in self.places.items() if p.get("role") == role), default=None)

    def leads_to(self, neighbour: Optional[int], role: str) -> Optional[str]:
        """Where a trip leaves the inside: the gateway towards ``neighbour``, or the place for ``role`` if it stays."""
        return self.place(role) if neighbour is None else self.gateways.get(neighbour)

    @classmethod
    def from_cabin_layout(cls, net: RoadNetwork, node: int, layout: dict, roles: Optional[dict] = None) -> "Inside":
        """The cabin's small city (its ``city-layout.json``) as the inside of ``node``.

        The layout gives positions as x (east) and z (south) in metres. A road that meets ``node`` enters the
        streets at an intersection on their edge: the one lying in the direction the road comes from. Each
        road gets its own, chosen so that the directions agree best over all roads.
        """
        roles = ROLES if roles is None else roles
        xs = [n["x"] for n in layout["nodes"]]
        zs = [n["z"] for n in layout["nodes"]]
        cx, cz = (min(xs) + max(xs)) / 2.0, (min(zs) + max(zs)) / 2.0
        at = {n["id"]: (n["x"] - cx, -(n["z"] - cz)) for n in layout["nodes"]}
        hosts = {p["nodeID"] for p in layout["pois"]}
        ends: dict = {}
        for edge in layout["edges"]:
            for a, b in ((edge["from"], edge["to"]), (edge["to"], edge["from"])):
                ends.setdefault(a, []).append(b)

        def straight_through(n: str) -> bool:        # a point along a street, not a junction of streets
            if len(ends[n]) != 2:
                return False
            (ax, ay), (bx, by), (x, y) = at[ends[n][0]], at[ends[n][1]], at[n]
            return abs((ax - x) * (by - y) - (ay - y) * (bx - x)) < 1e-6

        inside = cls(node=int(node), name=str(layout.get("id", "")))
        for n, (east, north) in at.items():
            mid = n in hosts or straight_through(n)
            inside.nodes[n] = (east, north, "midblock" if mid else "intersection")
        for edge in layout["edges"]:
            (ax, ay), (bx, by) = at[edge["from"]], at[edge["to"]]
            inside.links.append((edge["id"], edge["from"], edge["to"], math.hypot(bx - ax, by - ay)))
        for p in layout["pois"]:
            inside.places[p["id"]] = {"node": p["nodeID"], "east": p["x"] - cx, "north": -(p["z"] - cz),
                                      "type": p.get("kind", ""), "name": p.get("title", ""),
                                      "role": roles.get(p.get("kind", ""), "")}
        # every road that meets the node gets the edge intersection that lies its way
        x0, y0 = net.nodes[int(node)]
        roads = sorted({net.links[lid].v for lid in net.out[int(node)]})
        bearing = {v: _bearing(net.nodes[v][0] - x0, net.nodes[v][1] - y0) for v in roads}
        rim = sorted(n for n, (_e, _n, kind) in inside.nodes.items() if kind == "intersection" and _on_edge(at, n))
        if len(rim) < len(roads):
            raise ValueError(f"the inside has {len(rim)} intersections on its edge for the {len(roads)} roads at node {node}")
        faces = {n: _bearing(*at[n]) for n in rim}
        best = min(itertools.permutations(rim, len(roads)),
                   key=lambda pick: (round(sum(_apart(bearing[v], faces[n]) for v, n in zip(roads, pick)), 6), pick))
        inside.gateways = dict(zip(roads, best))
        for v, gateway in inside.gateways.items():     # a gateway is called after its road and where that leads
            road, to = net.road_names.get((int(node), v), ""), net.names.get(v, str(v))
            inside.names[gateway] = f"{road} towards {to}" if road and road != to else f"towards {to}"
        return inside


def _on_edge(at: dict, n: str) -> bool:
    xs, ys = [p[0] for p in at.values()], [p[1] for p in at.values()]
    x, y = at[n]
    return min(abs(x - min(xs)), abs(x - max(xs)), abs(y - min(ys)), abs(y - max(ys))) < 1e-6


def _bearing(east: float, north: float) -> float:
    """Degrees clockwise from north."""
    return math.degrees(math.atan2(east, north)) % 360.0


def _apart(a: float, b: float) -> float:
    d = abs(a - b) % 360.0
    return min(d, 360.0 - d)


# --------------------------------------------------------------------------- writing


def _table(folder: Path, name: str, columns: list, rows: list) -> None:
    with open(folder / name, "w", newline="", encoding="utf-8") as fh:
        out = csv.DictWriter(fh, fieldnames=columns, lineterminator="\n")
        out.writeheader()
        for row in rows:
            out.writerow({c: row.get(c, "") for c in columns})


def write(net: RoadNetwork, folder, name: str = "network", inside: Optional[Inside] = None) -> Path:
    """Write ``net`` as GMNS tables into ``folder``; with ``inside``, also the small network inside one node."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    geo = net.geo                                   # (latitude, longitude) local metres are measured from, if any
    _table(folder, "config.csv", CONFIG, [{
        "dataset_name": name, "short_length": "m", "long_length": "m", "speed": "km/h",
        "crs": "EPSG:4326" if geo else "", "geometry_field_format": "wkt", "currency": "USD",
        "version_number": VERSION, "id_type": "string",
        "origin_lat": repr(geo[0]) if geo else "", "origin_lon": repr(geo[1]) if geo else ""}])

    def where(node: int) -> tuple:                  # as written: longitude and latitude where the network has them
        if geo:
            lon, lat = net.lonlat[node]
            return repr(lon), repr(lat)
        x, y = net.nodes[node]
        return repr(x), repr(y)

    nodes = [{"node_id": n, "name": net.names.get(n, ""), "x_coord": where(n)[0], "y_coord": where(n)[1],
              "node_type": "district" if inside is not None and n == inside.node else "junction"}
             for n in sorted(net.nodes)]
    links = []
    for link in net.links:
        row = {"link_id": link.id, "name": net.road_names.get((link.u, link.v), ""), "from_node_id": link.u,
               "to_node_id": link.v, "directed": "true", "length": repr(link.length),
               "facility_type": net.road_class.get((link.u, link.v), ""),
               "capacity": repr(round(link.capacity * 3600.0, 6)) if link.capacity else "",
               "free_speed": repr(round(link.speed * 3.6, 6)), "lanes": link.lanes}
        if inside is not None and inside.node in (link.u, link.v):
            row["inner_node_id"] = inside.gateways[link.v if link.u == inside.node else link.u]
        links.append(row)
    locations = []
    if inside is not None:
        x0, y0 = net.nodes[inside.node]

        def put(east: float, north: float) -> tuple:
            if geo:
                lon0, lat0 = net.lonlat[inside.node]
                m_lon, m_lat = _metres_per_degree(geo)
                return repr(lon0 + east / m_lon), repr(lat0 + north / m_lat)
            return repr(x0 + east), repr(y0 + north)

        for n, (east, north, kind) in inside.nodes.items():
            x, y = put(east, north)
            nodes.append({"node_id": n, "name": inside.names.get(n, ""), "x_coord": x, "y_coord": y, "node_type": kind,
                          "zone_id": inside.name, "parent_node_id": inside.node})
        for lid, a, b, length in inside.links:
            links.append({"link_id": lid, "from_node_id": a, "to_node_id": b, "directed": "false",
                          "length": repr(length), "facility_type": "street", "lanes": 1})
        leaving = {a: lid for lid, a, _b, _length in reversed(inside.links)}        # a street that starts at the node
        arriving = {b: (lid, a, length) for lid, a, b, length in reversed(inside.links)}
        for pid, p in inside.places.items():
            x, y = put(p["east"], p["north"])
            if p["node"] in leaving:                # GMNS: a location lies on a link, measured from that link's from-node
                on, ref, along = leaving[p["node"]], p["node"], 0.0
            else:
                on, ref, along = arriving[p["node"]]
            locations.append({"loc_id": pid, "link_id": on, "ref_node_id": ref, "lr": repr(along), "x_coord": x,
                              "y_coord": y, "loc_type": p["type"], "zone_id": inside.name, "name": p["name"],
                              "role": p["role"]})
    _table(folder, "node.csv", NODE, nodes)
    _table(folder, "link.csv", LINK, links)
    if locations:
        _table(folder, "location.csv", LOCATION, locations)
    return folder


def _metres_per_degree(origin: tuple) -> tuple:
    east, north = metres_from(origin, origin[0] + 1.0, origin[1] + 1.0)
    return east, north


# --------------------------------------------------------------------------- reading


def _rows(folder: Path, name: str) -> list:
    path = folder / name
    if not path.exists():
        return []
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def read(folder) -> tuple:
    """The network in ``folder`` and, if the tables hold one, the small network inside one of its nodes."""
    folder = Path(folder)
    config = (_rows(folder, "config.csv") or [{}])[0]
    if config.get("long_length", "m") not in ("m", "km"):
        raise ValueError("config.csv: long_length must be m or km")
    to_m = 1000.0 if config.get("long_length") == "km" else 1.0
    if config.get("speed", "km/h") not in ("km/h", "m/s"):
        raise ValueError("config.csv: speed must be km/h or m/s")
    geo = (float(config["origin_lat"]), float(config["origin_lon"])) if config.get("origin_lat") else None
    rows = _rows(folder, "node.csv")
    if not rows:
        raise ValueError(f"{folder} has no node.csv")
    outer = [r for r in rows if not r.get("parent_node_id")]
    inner = [r for r in rows if r.get("parent_node_id")]
    if config.get("crs") == "EPSG:4326" and geo is None:        # longitude and latitude, from another tool
        geo = (float(outer[0]["y_coord"]), float(outer[0]["x_coord"]))
    net = RoadNetwork()
    net.geo = geo
    for r in outer:
        node, x, y = int(r["node_id"]), float(r["x_coord"]), float(r["y_coord"])
        if geo:
            net.lonlat[node] = (x, y)
            x, y = metres_from(geo, y, x)
        net.add_node(node, x, y)
        if r.get("name"):
            net.names[node] = r["name"]
    ids = {r["node_id"] for r in outer}
    for r in _rows(folder, "link.csv"):
        if r["from_node_id"] not in ids or r["to_node_id"] not in ids:
            continue                                # a street of the inside network
        u, v = int(r["from_node_id"]), int(r["to_node_id"])
        kmh = float(r["free_speed"]) if r.get("free_speed") else 36.0
        speed = round(kmh / 3.6, 9) if config.get("speed", "km/h") == "km/h" else kmh
        args = dict(length=float(r["length"]) * to_m if r.get("length") else None, speed=speed,
                    lanes=int(float(r["lanes"])) if r.get("lanes") else 1,
                    capacity_vph=float(r["capacity"]) if r.get("capacity") else 0.0)
        both = str(r.get("directed", "true")).strip().lower() in ("false", "0", "no")
        for a, b in ((u, v), (v, u)) if both else ((u, v),):
            net.add_link(a, b, **args)
            if r.get("name"):
                net.road_names[(a, b)] = r["name"]
            if r.get("facility_type"):
                net.road_class[(a, b)] = r["facility_type"]
    net.check_connected()
    return net, _inside(net, geo, inner, _rows(folder, "link.csv"), _rows(folder, "location.csv"), config)


def _inside(net: RoadNetwork, geo, inner: list, links: list, locations: list, config: dict) -> Optional[Inside]:
    if not inner:
        return None
    parents = {r["parent_node_id"] for r in inner}
    if len(parents) != 1:
        raise ValueError("node.csv: the nodes with a parent_node_id must all belong to one node")
    node = int(parents.pop())
    inside = Inside(node=node, name=next((r["zone_id"] for r in inner if r.get("zone_id")), config.get("dataset_name", "")))
    if geo:
        lon0, lat0 = net.lonlat[node]
        m_lon, m_lat = _metres_per_degree(geo)
        rel = lambda x, y: ((float(x) - lon0) * m_lon, (float(y) - lat0) * m_lat)          # noqa: E731
    else:
        x0, y0 = net.nodes[node]
        rel = lambda x, y: (float(x) - x0, float(y) - y0)                                  # noqa: E731
    for r in inner:
        east, north = rel(r["x_coord"], r["y_coord"])
        inside.nodes[r["node_id"]] = (east, north, r.get("node_type") or "intersection")
        if r.get("name"):
            inside.names[r["node_id"]] = r["name"]
    to_m = 1000.0 if config.get("long_length") == "km" else 1.0
    for r in links:
        if r["from_node_id"] in inside.nodes and r["to_node_id"] in inside.nodes:
            inside.links.append((r["link_id"], r["from_node_id"], r["to_node_id"], float(r["length"]) * to_m))
        elif r.get("inner_node_id"):
            u, v = int(r["from_node_id"]), int(r["to_node_id"])
            if node not in (u, v) or r["inner_node_id"] not in inside.nodes:
                raise ValueError(f"link.csv: link {r['link_id']} names an inner node that is not inside node {node}")
            other = v if u == node else u
            if inside.gateways.setdefault(other, r["inner_node_id"]) != r["inner_node_id"]:
                raise ValueError(f"link.csv: the two directions of the road to node {other} enter at different inner nodes")
    by_link = {lid: (a, b, length) for lid, a, b, length in inside.links}
    for r in locations:
        a, b, length = by_link[r["link_id"]]
        at = r["ref_node_id"] if float(r.get("lr") or 0.0) < length / 2.0 else (b if r["ref_node_id"] == a else a)
        east, north = rel(r["x_coord"], r["y_coord"])
        inside.places[r["loc_id"]] = {"node": at, "east": east, "north": north, "type": r.get("loc_type", ""),
                                      "name": r.get("name", ""), "role": r.get("role", "")}
    missing = sorted({net.links[lid].v for lid in net.out[node]} - set(inside.gateways))
    if missing:
        raise ValueError(f"link.csv: the roads from node {node} to {missing} do not say where they enter (inner_node_id)")
    return inside


@register_network("gmns")
def build_from_gmns(cfg) -> RoadNetwork:
    """A network from GMNS tables: ``network: {type: gmns, params: {path: <folder>}}``."""
    params = cfg.params or {}
    if "path" not in params:
        raise ValueError("network.type=gmns requires network.params.path")
    path = Path(params["path"])
    if not path.is_absolute() and getattr(cfg, "base_dir", None):
        path = Path(cfg.base_dir) / path
    return read(path)[0]


def cabin_layout(path) -> dict:
    """The cabin's city layout file (AgV Lab's ``city-layout.json``)."""
    return json.loads(Path(path).read_text(encoding="utf-8"))
