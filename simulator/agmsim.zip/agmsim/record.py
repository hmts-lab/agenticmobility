"""The decision record: one decision point, in a form the network simulation and the cabin both use.

A decision point is written down as seven things:

1. ``who``      -- who decides, and for whom;
2. ``trigger``  -- why it was asked;
3. ``sees``     -- what it was shown;
4. ``may``      -- what it may do, and ``default``: what happens where it has no say;
5. ``approval`` -- who has to agree before what was chosen is carried out;
6. ``chose``    -- what was chosen, by what (a rule, a language model, a person) and why;
7. ``outcome``  -- what came of it.

The network simulation writes every decision of a run in this form (:func:`from_trace`). Some of them can
be put to a person in the cabin simulator (AgV Lab, a robotaxi cabin on Apple Vision Pro): a car that may
take another route, a car that proposes to its owner to park and go on by transit, a car that has to
charge on the way. For those :func:`situation` adds a ``cabin`` block -- which of the cabin's scenes to
show, a briefing, and two options, each with the action it stands for in the simulation. The cabin's
recording of the ride is read back into the same form (:func:`read_cabin`), and the person's choice can be
put in place of the simulated agent's (:func:`apply`). So the same decision point can be answered by a
rule, by a language model or by a person.

The record separates what an agent *may do* (``may``) from who has to *agree* (``approval``). The two
platforms name their levels alike (0 to 4, after the same paper) but differ in exactly this: in the
network simulation a car at level 1 takes another route by itself, in the cabin a rider at level 2 and
above is asked.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Optional

from . import kinds as _kinds  # noqa: F401  (registers the built-in kinds)
from .kinds.base import KINDS
from .observation import clock
from .plans import parse_clock

FORMAT = "agms-decision-record"
VERSION = 1

#: Whom an agent of each kind acts for, where that is not one person (a car acts for its owner).
ACTS_FOR = {"traveler": "themselves", "ondemand": "the on-demand service, and the traveller on board",
            "bus": "the transit operator", "evcs": "the owner of the station", "signal": "the road authority",
            "operator": "the road authority"}
#: Actions that are proposals by their nature: they are carried out only if the one the agent acts for agrees
#: (unless the run sets ``agents.vehicle.approval: none``). Under ``approval: owner`` another route is one too;
#: such a decision is known by what came of it.
PROPOSALS = {("vehicle", "suggest_transfer")}
PROPOSED = ("suggested a bus transfer to the owner", "proposed another route to the owner")

#: The cabin's levels and scenes, as AgV Lab names them (its ``AgencyLevel`` and ``StudyScenario``).
CABIN_LEVELS = ("Non-agentic", "Context-aware", "Dialogic", "Adaptive", "Ethical & reflective")
CABIN_ASKS_FROM = 2            # from this level on the rider is asked; below it the cabin answers in a fixed way
CABIN_SCENARIOS = {
    "quietArrival": ("Quiet arrival", "Clarify a goal", ("Prioritize quiet", "Prioritize arrival")),
    "roadClosure": ("Road closure", "Explain and revise a plan", ("Compare alternatives", "Wait for an update")),
    "sharedRideConflict": ("Shared-ride priorities", "Negotiate competing needs", ("Discuss a shared plan", "Keep stop order")),
    "medicalConcern": ("Passenger support", "Offer help with consent", ("Pause the experience", "Discuss support")),
    "weatherDisruption": ("Weather disruption", "Adapt to changing conditions", ("Prioritize comfort", "Review arrival time")),
    "errandCoordination": ("Multi-stop errands", "Coordinate multiple tasks", ("Appointment first", "Pickup first")),
    "energyPlanning": ("Charging and arrival", "Manage energy proactively", ("Plan a charging stop", "Compare options")),
    "sensorUncertainty": ("Sensor uncertainty", "Explain system limits", ("Pause and reassess", "Explain the limits")),
}
CABIN_TRIGGER_SECONDS = 20     # the cabin shows a scenario's card this far into the ride
#: Participant codes under which the cabin's own programs record a ride. Such a ride goes through the cabin
#: like any other, but no rider chose anything in it, and a record read from it says so.
CABIN_PROGRAMS = {"automated_fixture": "the cabin's check program",
                  "REHEARSAL": "the Mac preview's scripted rehearsal"}
#: The longest texts the cabin accepts, in UTF-8 bytes (its ``DecisionSituation``); it refuses a file with longer ones.
CABIN_LIMITS = {"id": 256, "briefing": 1200, "label": 120}


# --------------------------------------------------------------------------- from a run of the network simulation


def _trace(source) -> list:
    """The records of a run: a list of them, or the directory the run was written to."""
    if isinstance(source, (str, Path)):
        from .recorder import read_trace
        return read_trace(source)
    return list(source)


def _by(source: str, cfg: dict) -> str:
    if source == "forced":
        return "nobody: it has no say here, the default applies"
    if source == "answer":
        return "an answer given from outside"
    if source == "replay":
        return "replayed from a recording"
    if source == "llm":
        from .config import LLMCfg
        llm = LLMCfg(**cfg.get("llm", {})).resolved()
        return f"language model: {llm.model or llm.backend or 'unnamed'}"
    return f"built-in model: {source}"


def from_trace(source) -> list:
    """Every decision of a recorded run as a decision record, in the order they were taken."""
    records = _trace(source)
    header = records[0]
    if header.get("type") != "header":
        raise ValueError("the trace does not start with a header record")
    cfg = header["config"]
    dt = float(cfg["simulation"]["time_step_seconds"])
    clock0 = parse_clock(cfg["simulation"]["clock_start"])
    run = cfg["record"].get("run_name") or f"{cfg['name']}-seed{cfg['simulation']['seed']}"
    arrivals: dict = {}
    for r in records:
        if r["type"] == "event" and r["event"] == "arrived":
            arrivals.setdefault(r["agent"], []).append((r["tick"], r.get("mode")))
    out = []
    for r in records:
        if r["type"] != "decision":
            continue
        kind, agent, tick = r["kind"], r["agent"], r["tick"]
        meta = KINDS.get(kind) if kind in KINDS.names() else None
        person = "H" + agent[1:] if kind == "vehicle" else agent if kind == "traveler" else None
        acts_for = {"id": person, "kind": "traveler"} if kind == "vehicle" else ACTS_FOR.get(kind, "")
        decision, obs = r["decision"], r.get("obs")
        record = {
            "format": FORMAT, "version": VERSION, "id": f"{run}/{agent}/{tick}",
            "from": {"platform": "agmsim", "run": run, "scenario": cfg["name"], "seed": cfg["simulation"]["seed"],
                     "config_digest": header.get("config_digest"), "tick": tick, "clock": clock(clock0 + tick * dt)},
            "who": {"decides": agent, "kind": kind, "side": getattr(meta, "side", ""), "level": r.get("level", ""),
                    "for": acts_for},
            "trigger": {"name": r["trigger"], "why": (getattr(meta, "triggers", {}) or {}).get(r["trigger"], "")},
        }
        if obs is not None:
            record["sees"] = {k: obs[k] for k in ("state", "context", "memory") if k in obs}
            record["may"] = [{"action": a["action"], "means": a.get("description", ""), "args": a.get("args", {})}
                             for a in obs["permitted_actions"]]
        else:
            record["may"] = [{"action": name} for name in r.get("permitted", [])]
        if "default" in r:
            record["default"] = r["default"]
        asked_nobody = (cfg.get("agents", {}).get("vehicle") or {}).get("approval") == "none"
        needs = r.get("result") in PROPOSED or ((kind, decision["action"]) in PROPOSALS and not asked_nobody)
        record["approval"] = ({"by": acts_for, "how": "accepts or declines what is proposed"} if needs
                              else {"by": None, "how": "what is chosen is carried out as it is"})
        chose = {"action": decision["action"], "args": decision.get("args") or {}, "by": _by(r["source"], cfg)}
        if decision.get("rationale"):
            chose["why"] = decision["rationale"]
        if "exercised" in r:
            chose["other_than_default"] = r["exercised"]
        if r.get("valid") is False:
            chose["unusable"] = r.get("error", "")
        if "took_effect" in r:
            chose["took_effect"] = clock(clock0 + r["took_effect"] * dt)
        if r.get("came_too_late"):
            chose["came_too_late"] = True
        if "took_effect_as" in r:
            chose["carried_out_as"] = r["took_effect_as"]
        record["chose"] = chose
        outcome = {}
        if r.get("result"):
            outcome["result"] = r["result"]
        if r.get("note"):
            outcome["note"] = r["note"]
        if person is not None:              # what came of the trip it was part of
            done = next(((t, mode) for t, mode in arrivals.get(person, []) if t >= tick), None)
            if done is not None:
                outcome["trip"] = {"arrived": clock(clock0 + done[0] * dt), "mode": done[1],
                                   "minutes_after_this_decision": round((done[0] - tick) * dt / 60.0, 1)}
        record["outcome"] = outcome
        out.append(record)
    return out


# --------------------------------------------------------------------------- a decision point as a situation for the cabin


def _place(names: dict, node) -> str:
    return names.get(str(node), f"node {node}")


def _route_situation(record: dict, names: dict) -> Optional[dict]:
    rows = record["sees"]["context"].get("routes") or []
    if len(rows) < 2 or not record["sees"]["state"].get("carrying_owner", True):
        return None
    if (record.get("approval") or {}).get("by") is not None:
        return None                     # the car put it to its owner: the owner's answer is the decision point to show
    now = rows[0]
    other = min(rows[1:], key=lambda row: (row["eta_min"], row["route"]))
    weather = (record["sees"]["context"].get("environment") or {}).get("weather")

    def via(row):                       # the first junction on it that the route the car is on does not pass
        if "via_nodes" not in row or "via_nodes" not in now:
            return ""
        new = [n for n in row["via_nodes"] if n not in now["via_nodes"]]
        return f" via {_place(names, new[0])}" if new else ""

    def cost(row):
        return f", {row['toll_usd']:g} USD in tolls" if row.get("toll_usd") else ""

    lead = (f"Because of the weather ({weather}), traffic is slower than usual. " if weather
            else "Traffic on the way ahead has changed. ")
    briefing = (f"{lead}The route you are on now takes about {now['eta_min']:.0f} minutes ({now['km']:g} km{cost(now)}). "
                f"Another route{via(other)} takes about {other['eta_min']:.0f} minutes ({other['km']:g} km{cost(other)}). "
                "Which should the car take?")
    options = [
        {"label": "Stay on this route", "minutes": now["eta_min"], "km": now["km"], "cost_usd": now.get("toll_usd", 0.0),
         "answer": {"action": "choose_route", "args": {"route": now["route"]}}},
        {"label": f"Take the other route{via(other)}", "minutes": other["eta_min"], "km": other["km"],
         "cost_usd": other.get("toll_usd", 0.0), "answer": {"action": "choose_route", "args": {"route": other["route"]}}},
    ]
    return {"scenario": "weatherDisruption" if weather else "roadClosure", "briefing": briefing, "options": options,
            "weather": weather}


def _transfer_situation(record: dict, names: dict) -> Optional[dict]:
    context = record["sees"]["context"]
    p, keep = context.get("proposal"), context.get("if_you_keep_driving_min")
    if not p or keep is None:
        return None
    said = f" It says: \"{p['message_from_vehicle']}\"" if p.get("message_from_vehicle") else ""
    briefing = (f"The road ahead is slow: driving on takes about {keep:.0f} minutes. Your car proposes to park at "
                f"{_place(names, p['stop'])} and go on by transit (line {p['line']}): about {p['total_min']:.0f} minutes in all, "
                f"with {p['walk_min']:.0f} minutes on foot and a fare of {p['bus_fare_usd']:g} USD.{said} Do you agree?")
    options = [
        {"label": "Park and go on by transit", "minutes": p["total_min"], "cost_usd": p["bus_fare_usd"],
         "answer": {"action": "accept_suggestion", "args": {}}},
        {"label": "Keep driving", "minutes": keep, "cost_usd": 0.0, "answer": {"action": "decline_suggestion", "args": {}}},
    ]
    return {"scenario": "roadClosure", "briefing": briefing, "options": options, "weather": None}


def _route_proposal_situation(record: dict, names: dict) -> Optional[dict]:
    """Another route that the car put to its owner (``agents.vehicle.approval: owner``)."""
    context = record["sees"]["context"]
    new, now = context.get("proposal"), context.get("if_you_stay_on_this_route")
    if not new or not now:
        return None
    weather = (context.get("environment") or {}).get("weather")
    via = ""
    if "via_nodes" in new and "via_nodes" in now:
        other = [n for n in new["via_nodes"] if n not in now["via_nodes"]]
        via = f" via {_place(names, other[0])}" if other else ""

    def cost(row):
        return f", {row['toll_usd']:g} USD in tolls" if row.get("toll_usd") else ""

    lead = (f"Because of the weather ({weather}), traffic is slower than usual. " if weather
            else "Traffic on the way ahead has changed. ")
    briefing = (f"{lead}The route you are on now takes about {now['eta_min']:.0f} minutes ({now['km']:g} km{cost(now)}). "
                f"Your car proposes another route{via}: about {new['eta_min']:.0f} minutes ({new['km']:g} km{cost(new)}). "
                "Do you agree?")
    options = [
        {"label": "Stay on this route", "minutes": now["eta_min"], "km": now["km"], "cost_usd": now.get("toll_usd", 0.0),
         "answer": {"action": "decline_suggestion", "args": {}}},
        {"label": f"Take the proposed route{via}", "minutes": new["eta_min"], "km": new["km"],
         "cost_usd": new.get("toll_usd", 0.0), "answer": {"action": "accept_suggestion", "args": {}}},
    ]
    return {"scenario": "weatherDisruption" if weather else "roadClosure", "briefing": briefing, "options": options,
            "weather": weather}


def _proposal_situation(record: dict, names: dict) -> Optional[dict]:
    """What a car proposed to its owner: another route, or parking and going on by transit."""
    proposal = record["sees"]["context"].get("proposal") or {}
    build = _route_proposal_situation if proposal.get("type") == "take another route" else _transfer_situation
    return build(record, names)


def _charge_situation(record: dict, names: dict) -> Optional[dict]:
    rows = record["sees"]["context"].get("stations") or []
    if len(rows) < 2 or not record["sees"]["state"].get("carrying_owner"):
        return None
    first = rows[0]                     # the nearest on the way: what the car does if nobody chooses
    other = min(rows[1:], key=lambda row: (row["vehicles_queued"] + row["chargers_in_use"] - row["chargers"],
                                           row["price_usd_per_kwh"], row["km"], row["station"]))
    battery = record["sees"]["state"].get("battery") or {}

    def text(row):
        onward = f" and {row['then_to_destination_km']:.0f} km from your destination" if "then_to_destination_km" in row else ""
        where = _place(names, row["node"])
        at = "" if where == row["station"] else f" ({where})"
        return (f"{row['station']}{at}, {row['drive_min']:.0f} minutes away{onward}: "
                f"{row['price_usd_per_kwh']:g} USD per kWh, {row['chargers_in_use']} of {row['chargers']} chargers in use, "
                f"{row['vehicles_queued']} waiting")

    left = f" The battery is at {battery['charge_pct']}%." if "charge_pct" in battery else ""
    briefing = (f"The car cannot reach your destination without charging.{left} It can stop at {text(first)}; or at {text(other)}. "
                "Where should it charge?")
    options = [{"label": f"Charge at {row['station']}", "minutes": row["drive_min"], "price_usd_per_kwh": row["price_usd_per_kwh"],
                "answer": {"action": "charge", "args": {"station": row["station"]}}} for row in (first, other)]
    return {"scenario": "energyPlanning", "briefing": briefing, "options": options, "weather": None}


#: (kind, trigger) -> what the cabin is to show for such a decision point
SITUATIONS = {("vehicle", "route"): _route_situation, ("traveler", "suggestion"): _proposal_situation,
              ("vehicle", "charge"): _charge_situation}


def _first_hops(network: dict, src: int) -> dict:
    """For every node, the node to drive to first from ``src`` on the quickest way there (free roads)."""
    out_links: dict = {}
    for _lid, u, v, length, speed, _lanes in network["links"]:
        out_links.setdefault(u, []).append((v, length / max(speed, 0.1)))
    import heapq
    best, first, heap = {src: 0.0}, {}, [(0.0, src, None)]
    while heap:
        t, node, hop = heapq.heappop(heap)
        if t > best.get(node, float("inf")):
            continue
        if hop is not None:
            first.setdefault(node, hop)
        for v, dt in sorted(out_links.get(node, ())):
            if t + dt < best.get(v, float("inf")):
                best[v] = t + dt
                first[v] = v if node == src else first[node]
                heapq.heappush(heap, (t + dt, v, first[v]))
    return first


def _ride(record: dict, options: list, inside, hops: dict) -> Optional[dict]:
    """The decision point as a ride through the inside of a node: where the ride starts, and where each option leads.

    None unless the car is there: about to enter the node (the ride starts at the gateway of the road it is
    on) or setting off from it (it starts at the place trips leave from). An option leads to the gateway of
    the road it takes next, or to a place inside if it goes no further. Routes have to say which junctions
    they pass (``agents.vehicle.observation.route_roads``).
    """
    context, state = record["sees"]["context"], record["sees"]["state"]
    where = (state if record["who"]["kind"] == "vehicle" else context).get("location") or {}
    if where.get("next_node") == inside.node:
        origin = inside.gateways.get(where["between_nodes"][0])
    elif where.get("node") == inside.node:
        origin = inside.place("departures")
    else:
        return None

    def onward(row: dict) -> Optional[str]:             # where a route goes next from the node
        via = row.get("via_nodes")
        if not via or via[0] != inside.node:
            return None
        return inside.leads_to(via[1] if len(via) > 1 else None, "arrivals")

    leads = []
    for option in options:
        action, args = option["answer"]["action"], option["answer"].get("args") or {}
        if action == "choose_route":
            lead = onward(next(r for r in context["routes"] if r["route"] == args["route"]))
        elif action in ("accept_suggestion", "decline_suggestion") and (context.get("proposal") or {}).get("type") == "take another route":
            lead = onward(context["proposal"] if action == "accept_suggestion" else context["if_you_stay_on_this_route"])
        elif action == "charge":
            node = next(r for r in context["stations"] if r["station"] == args["station"])["node"]
            lead = inside.place("charging") if node == inside.node else inside.gateways.get(hops.get(node))
        else:
            lead = None
        if lead is None or lead == origin:
            return None
        leads.append(lead)
    return None if origin is None else {"origin": origin, "leads": leads}


def situation(record: dict, names: Optional[dict] = None, inside=None, hops: Optional[dict] = None) -> Optional[dict]:
    """The decision point as a situation for the cabin: the record with a ``cabin`` block, or None.

    None if the cabin has no scene for this kind of decision point, if the record does not say what the
    agent saw (a default decision in a run recorded without ``record.observations: all``), if there are
    not two things to choose between, or if its texts are longer than the cabin accepts
    (:data:`CABIN_LIMITS`). ``names`` gives places their names (the trace header's ``network.names``).
    The answer the simulated agent gave is left out: it is not for the rider to see.

    With ``inside`` (:class:`agmsim.gmns.Inside`, the cabin's city as the inside of one node) only decision
    points at that node are situations, and each says the ride through the cabin's city that it is part of:
    ``cabin.place``, ``cabin.journey`` (where the ride starts and where it is heading as it starts) and, for
    each option, the ``journey`` it leads to. ``hops`` are the first nodes on the way from that node
    (:func:`_first_hops`).
    """
    build = SITUATIONS.get((record["who"]["kind"], record["trigger"]["name"]))
    if build is None or "sees" not in record:
        return None
    cabin = build(record, names or {})
    if cabin is None:
        return None
    title, capability, _choices = CABIN_SCENARIOS[cabin["scenario"]]
    permitted = {a["action"] for a in record["may"]}
    if not all(option["answer"]["action"] in permitted for option in cabin["options"]):
        return None
    size = lambda text: len(text.encode("utf-8"))                                        # noqa: E731
    first, second = (option["label"] for option in cabin["options"])
    if (size(record["id"]) > CABIN_LIMITS["id"] or size(cabin["briefing"]) > CABIN_LIMITS["briefing"]
            or max(size(first), size(second)) > CABIN_LIMITS["label"]
            or first.strip().lower() == second.strip().lower()):
        return None
    who = record["who"]
    at = f"the {who['kind']} {who['decides']} at level {who['level'] or '?'}"
    if record.get("chose", {}).get("by", "").startswith("nobody"):
        in_simulation = f"nobody decided: {at} has no say here, and the default applied"
    elif record["approval"]["by"] is None and who["side"] == "machine":
        in_simulation = f"decided by {at}, by itself"
    else:
        in_simulation = f"decided by {at}"
    out = {k: v for k, v in record.items() if k not in ("chose", "outcome")}
    out["cabin"] = {"scenario": cabin["scenario"], "title": title, "capability": capability,
                    "trigger_seconds": CABIN_TRIGGER_SECONDS, "briefing": cabin["briefing"], "options": cabin["options"],
                    "weather": cabin["weather"], "in_the_simulation": in_simulation}
    if inside is not None:
        ride = _ride(record, cabin["options"], inside, hops or {})
        if ride is None:
            return None                     # not at that node, or the record does not say which way its options go
        out["cabin"]["place"] = {"node": inside.node, "name": (names or {}).get(str(inside.node), ""), "inside": inside.name}
        out["cabin"]["journey"] = {"origin": ride["origin"], "stops": [ride["leads"][0]]}
        out["cabin"]["options"] = [{**option, "journey": {"stops": [lead]}}
                                   for option, lead in zip(cabin["options"], ride["leads"])]
    return out


def situations(source, limit: Optional[int] = None, inside=None) -> list:
    """Every decision point of a recorded run that the cabin can show, as situations.

    With ``limit``: for each of the cabin's scenes, the ``limit`` situations in which the most is at stake
    (the two options being furthest apart in minutes). With ``inside`` (the cabin's city as the inside of one
    node, :class:`agmsim.gmns.Inside`): only the decision points at that node, each with the ride it is part of.
    """
    records = _trace(source)
    network = records[0].get("network") or {}
    names = network.get("names") or {}
    hops = _first_hops(network, inside.node) if inside is not None else None
    found = [s for s in (situation(record, names, inside, hops) for record in from_trace(records)) if s is not None]
    if limit is not None:
        apart = lambda s: abs(s["cabin"]["options"][0]["minutes"] - s["cabin"]["options"][1]["minutes"])     # noqa: E731
        ranked, taken = sorted(found, key=lambda s: (-apart(s), s["id"])), {}
        found = []
        for s in ranked:
            scene = s["cabin"]["scenario"]
            if taken.get(scene, 0) < limit:
                taken[scene] = taken.get(scene, 0) + 1
                found.append(s)
    return found


# --------------------------------------------------------------------------- back from the cabin


def _cabin_events(folder: Path) -> list:
    """The events of a cabin session: from ``events.ndjson``, or from ``events.csv`` where only that was exported."""
    lines = folder / "events.ndjson"
    if lines.exists() and lines.stat().st_size:
        return [json.loads(line) for line in lines.read_text(encoding="utf-8").splitlines() if line.strip()]
    table = folder / "events.csv"
    if not table.exists():
        raise FileNotFoundError(f"{folder} has neither events.ndjson nor events.csv")
    import csv
    with open(table, newline="", encoding="utf-8") as fh:
        return [{"schemaVersion": int(row["schema_version"]), "sessionID": row["session_id"], "sequence": int(row["sequence"]),
                 "timeUTC": row["time_utc"], "elapsedSeconds": float(row["elapsed_seconds"]),
                 "routeSeconds": float(row["route_seconds"]), "event": row["event"].lstrip("'"),
                 "details": json.loads(row["details_json"] or "{}")} for row in csv.DictReader(fh)]


def read_cabin(session_dir, situation=None) -> list:
    """The decision points of a ride recorded by the cabin, as decision records.

    ``session_dir`` holds the cabin's ``metadata.json`` and its events (``events.ndjson``, or ``events.csv``
    where only that was exported). One record is returned for every time a scenario was put to the rider
    (from a ``scenario_reset`` to the next one). With the situation the ride was run on, the record says
    which decision point of the network simulation it answers (``about``) and what the rider's choice is as
    an action there (``chose.answer``).

    The cabin keeps the situation it played in the session folder (``situation.json``, with its SHA-256 in
    ``metadata.json``) and names it in its events (``details.situation``); that file is used, and a
    ``situation`` given here has to be the same one. Where the folder does not hold it (a session exported
    from the headset file by file), give the situation: as a path, the file is checked against that SHA-256.
    A ride on one of the cabin's own scenes names no situation and answers no decision point.

    For recorded traffic, ``chose`` keeps the last timely rider choice and ``outcome`` records the
    ride carried out and any late attempts. The traffic receipt and the choice events must agree.
    """
    from .record_traffic import load_traffic, traffic_outcome

    folder = Path(session_dir)
    meta = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
    expected_sha = meta.get("situationSHA256")
    situation_sha = None
    kept = folder / "situation.json"
    if isinstance(situation, (str, Path)):
        given = Path(situation).read_bytes()
        if not kept.exists():
            digest = hashlib.sha256(given).hexdigest()
            if expected_sha and digest != expected_sha:
                raise ValueError(f"{situation} is not the file the cabin loaded for this ride "
                                 "(its SHA-256 differs from the one in metadata.json)")
            situation_sha = digest
        situation = json.loads(given.decode("utf-8"))
    if kept.exists():
        data = kept.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        if expected_sha and digest != expected_sha:
            raise ValueError("situation.json in the session folder is not the file the cabin loaded "
                             "(its SHA-256 differs from the one in metadata.json)")
        situation_sha = digest
        own = json.loads(data.decode("utf-8"))
        if situation is not None:
            if situation["id"] != own["id"]:
                raise ValueError(f"the ride was run on situation '{own['id']}', not on '{situation['id']}'")
            if json.dumps(situation["cabin"], sort_keys=True) != json.dumps(own["cabin"], sort_keys=True):
                raise ValueError(f"the ride was run on situation '{own['id']}', but what the rider was told there "
                                 "differs from the file given")
        situation = own
    if situation is not None and meta.get("situationID") not in (None, situation["id"]):
        raise ValueError(f"the ride was run on situation '{meta['situationID']}', not on '{situation['id']}'")
    traffic = load_traffic(folder, meta, situation, situation_sha)
    rows = _cabin_events(folder)
    rows.sort(key=lambda row: row["sequence"])
    if traffic is None and any(row["event"] in ("traffic_loaded", "traffic_ride_changed")
                               or row["event"] == "scenario_choice" and row["details"].get("traffic_id") for row in rows):
        raise ValueError("the cabin events name a traffic recording but its metadata is missing")
    runs, current = [], []
    has_scenario = False
    for row in rows:
        event = row["event"]
        # The native recorder writes initial traffic events before the first
        # scenario reset. On restart it changes the ride after route_reset.
        new_run = (event == "scenario_reset" and (traffic is None or has_scenario)
                   or traffic is not None and event == "route_reset")
        if new_run and current:
            runs.append(current)
            current = []
            has_scenario = False
        current.append(row)
        has_scenario |= event in ("scenario_reset", "scenario_triggered", "scenario_choice")
    if current:
        runs.append(current)
    out = []
    for events in runs:
        asked = next((e for e in events if e["event"] == "scenario_triggered"), None)
        attempts = [e for e in events if e["event"] == "scenario_choice"]
        if traffic is None:
            timely, late, recorded_outcome = attempts, [], {}
        else:
            timely, late, recorded_outcome = traffic_outcome(events, meta, situation, traffic)
        choices = [e for e in timely if e["details"].get("control") != "traffic_default"]
        if asked is None and not attempts:
            continue
        first = asked or attempts[0]
        reset = next((e for e in events if e["event"] == "scenario_reset"), None)
        scenario = first["details"].get("scenario") or meta.get("scenario") or ""
        label = (reset or first)["details"].get("agency") or (f"AgV-{meta['agency']}" if meta.get("agency") is not None else "")
        level = int(label.rsplit("-", 1)[1]) if label else None
        named = next((e["details"]["situation"] for e in events if e["details"].get("situation")), None)
        if situation is not None and named != situation["id"]:
            raise ValueError(f"the ride was run on situation '{named}', not on '{situation['id']}'" if named is not None else
                             f"the ride was not run on a situation (its events name none), so '{situation['id']}' "
                             "does not apply to it")
        title, capability, built_in = CABIN_SCENARIOS.get(scenario, (scenario, "", ()))
        rider = {"id": meta.get("participantCode", ""), "kind": "traveler"}
        program = CABIN_PROGRAMS.get(rider["id"])           # a ride recorded by a program, not by a rider
        asks = level is not None and level >= CABIN_ASKS_FROM
        record = {
            "format": FORMAT, "version": VERSION, "id": f"{meta['sessionID']}/{first['sequence']}",
            "from": {"platform": "agv_lab", "session": meta["sessionID"], "source": meta.get("source"),
                     "stimulus": meta.get("stimulusVersion"), "route": meta.get("routeID"),
                     "route_seconds": asked["routeSeconds"] if asked else None},
            "about": situation["id"] if situation is not None else named,
            "who": {"decides": rider["id"] if asks else "the cabin's agent", "kind": "traveler" if asks else "vehicle",
                    "side": "human" if asks else "machine", "level": label,
                    "level_name": CABIN_LEVELS[level] if level is not None and level < len(CABIN_LEVELS) else "",
                    "for": "themselves" if asks else rider},
            "trigger": {"name": scenario, "why": f"{title}: {capability}".strip(": ")},
        }
        if program:
            record["who"]["stand_in"] = program
            if asks:
                record["who"]["side"] = "machine"           # a program in the rider's place
        if situation is not None:
            record["sees"] = {**situation.get("sees", {}), "told": situation["cabin"]["briefing"]}
            record["may"] = [{"option": i, "label": o["label"], "stands_for": o["answer"]}
                             for i, o in enumerate(situation["cabin"]["options"])]
        else:
            record["may"] = [{"option": i, "label": text} for i, text in enumerate(built_in)]
        record["approval"] = ({"by": rider, "how": "chooses, or agrees to the agent's plan in conversation"} if asks
                              else {"by": None, "how": "the cabin answers in a fixed way at this level; the rider is not asked"})
        if choices:
            last = choices[-1]
            index = int(last["details"]["choice_index"])
            chose = {"option": index, "label": last["details"].get("choice", ""),
                     "by": f"a program: {program}" if program else "a person",
                     "how": "in conversation with the agent" if last["details"].get("control") == "agent_plan" else "a button",
                     "times_chosen": len(choices)}
            before = (choices[-2]["details"]["choice_index"] if traffic is not None and len(choices) > 1
                      else last["details"].get("previous_choice"))
            if before not in (None, "none"):
                chose["changed_from_option"] = int(before)
            if asked is not None:
                chose["seconds_after_asked"] = round(last["elapsedSeconds"] - asked["elapsedSeconds"], 1)
            if situation is not None:
                options = situation["cabin"]["options"]
                if not 0 <= index < len(options):
                    raise ValueError(f"the rider chose option {index}, which the situation does not have")
                if chose["label"] != options[index]["label"]:
                    raise ValueError(f"the rider chose '{chose['label']}', but option {index} of the situation "
                                     f"is '{options[index]['label']}'")
                chose["answer"] = options[index]["answer"]
        elif late:
            chose = {"by": "nobody: no rider choice came in time"}
        else:
            chose = {"by": "nobody: the cabin's fixed answer" if not asks else "nobody: the rider did not choose"}
        record["chose"] = chose
        since = first["sequence"]
        later = [e for e in events if e["sequence"] > since]
        plans = [e["details"] for e in later if e["event"] == "agent_action_applied"]
        stops = next((e["details"].get("stops", "") for e in reversed(later) if e["event"] == "itinerary_planned"), None)
        done = next((e for e in later if e["event"] == "route_complete"), None)
        outcome = {"agent_actions": [{k: v for k, v in d.items() if v != ""} for d in plans],
                   "routes_replanned": sum(1 for e in later if e["event"] == "route_replanned"),
                   "pauses": sum(1 for e in later if e["event"] == "route_pause"),
                   "ride_completed": done is not None}
        if stops is not None:
            outcome["stops_planned"] = [s for s in stops.split(",") if s]
        if done is not None:
            outcome["route_seconds_at_arrival"] = done["routeSeconds"]
        outcome.update(recorded_outcome)
        record["outcome"] = outcome
        out.append(record)
    return out


def _stand_in_traffic(situation, situation_bytes, traffic_path, attempts, agency, in_conversation):
    """Make the native recorder's traffic events from choices on its route clock."""
    traffic_bytes = Path(traffic_path).read_bytes()
    traffic = json.loads(traffic_bytes)
    if traffic.get("situation") != {"id": situation["id"], "sha256": hashlib.sha256(situation_bytes).hexdigest()}:
        raise ValueError("traffic does not match the stand-in situation's id and SHA-256")
    traffic_id = traffic["id"]
    traffic_sha = hashlib.sha256(traffic_bytes).hexdigest()
    branch = traffic["branch"]
    slots, trigger = branch["slots"], branch["trigger"]
    rides = {(r["option"], r["slot"]): r for r in traffic["rides"]}
    active = (branch["default"], len(slots) - 1)
    selected = None
    asks = agency >= CABIN_ASKS_FROM
    labels = [option["label"] for option in situation["cabin"]["options"]]
    base = {"scenario": situation["cabin"]["scenario"], "situation": situation["id"]}
    files = {"traffic.json": traffic_bytes}

    def timing(slot):
        return {"slot_time": str(float(slots[slot]["time"])), "decide_by": str(float(slots[slot]["decide_by"]))}

    def ride_changed(pair, reason, elapsed, route_seconds):
        ride = rides[pair]
        option, slot = pair
        route_id = f"{traffic_id}/{slot}/{option}"
        route = {"id": route_id, "durationSeconds": ride["arrives"], "tickRate": traffic["ego_rate"],
                 "samples": ride["ego"], "recordedTrafficID": traffic_id}
        file = "route.json" if reason == "session_start" else f"route-revision-00000000-0000-4000-8000-{len(files):012d}.json"
        files[file] = json.dumps(route, separators=(",", ":"), sort_keys=True).encode("utf-8")
        return ("traffic_ride_changed", elapsed, route_seconds,
                {"id": traffic_id, "option": str(option), "slot": str(slot), "route_id": route_id, "reason": reason,
                 **timing(slot), "file": file, "sha256": hashlib.sha256(files[file]).hexdigest()})

    initial = ride_changed(active, "session_start", 0.1, 0.0)
    events = [("session_start", 0.0, 0.0, {"source": "mac_preview"}),
              ("traffic_loaded", 0.1, 0.0, {"id": traffic_id, "sha256": traffic_sha, "rides": str(len(rides)),
                                                "slots": str(len(slots)), "closed_edges": ",".join(traffic["closed_edges"]),
                                                "vehicles": str(len({v["id"] for r in rides.values() for v in r["vehicles"]})),
                                                "maximum_path_deviation_m": "0"}),
              initial,
              ("scenario_reset", 0.5, 0.0, {**base, "agency": f"AgV-{agency}"}),
              ("route_start", 2.0, 0.0, {}),
              ("scenario_triggered", trigger + 2.0, trigger, {**base, "agency": f"AgV-{agency}",
                                                                "stage": "awaiting_choice" if asks else "resolved"})]

    previous = None
    last_time = trigger
    if not asks:
        attempts = [(branch["default"], trigger)]
    for option, seconds in attempts:
        if type(option) is not int or not 0 <= option < len(labels):
            raise ValueError("a stand-in choice needs a valid option index")
        if type(seconds) not in (int, float) or not last_time <= seconds <= rides[active]["arrives"]:
            raise ValueError("stand-in choices must be ordered on the route clock, from the trigger to arrival")
        last_time = seconds
        elapsed = seconds + 2.0
        latest = slots[selected if selected is not None else -1]["decide_by"]
        slot = (next((i for i, s in enumerate(slots) if seconds <= s["decide_by"] + 1e-9), None)
                if seconds <= latest + 1e-9 else None)
        control = ("traffic_default" if not asks else "agent_plan" if in_conversation else f"scenario_choice_{option}")
        if slot is not None:
            selected = slot
            if active != (option, slot):
                active = (option, slot)
                events.append(ride_changed(active, control, elapsed, seconds))
        details = {**base, "choice_index": str(option), "choice": labels[option], "control": control,
                   "traffic_id": traffic_id, "too_late": "true" if slot is None else "false",
                   "carried_out_option": str(active[0]), "carried_out_slot": str(active[1]),
                   **timing(active[1])}
        if slot is not None:
            details["slot"] = str(slot)
        if control == "agent_plan":
            details["previous_choice"] = "none" if previous is None else str(previous)
        events.append(("scenario_choice", elapsed, seconds, details))
        previous = option

    arrival = rides[active]["arrives"]
    destination = rides[active]["nodes"][-1]
    events += [("stop_arrived", arrival + 2.0, arrival, {"stop": destination, "remaining_stops": destination}),
               ("route_complete", arrival + 2.0, arrival, {"destination": destination, "completed_stops": destination}),
               ("session_finish", arrival + 3.0, arrival, {})]
    meta = {"trafficID": traffic_id, "trafficSHA256": traffic_sha, "trafficClosedEdges": traffic["closed_edges"],
            "routeID": initial[3]["route_id"], "effectiveRouteSHA256": initial[3]["sha256"],
            "routeDurationSeconds": rides[branch["default"], len(slots) - 1]["arrives"],
            "vehicleMotionVersion": "recorded-traffic-v1"}
    return events, meta, files


def _stand_in_timestamp(seconds):
    from datetime import datetime, timedelta, timezone

    time = datetime(2026, 1, 1, tzinfo=timezone.utc) + timedelta(seconds=seconds)
    return time.isoformat(timespec="milliseconds").replace("+00:00", "Z")


def stand_in_session(directory, situation, choice: Optional[int] = None, agency: int = 3, participant: str = "TEST01",
                     in_conversation: bool = False, *, traffic=None, choice_route_seconds=None, choice_attempts=None) -> Path:
    """Write what the cabin records for a ride on ``situation`` in which the rider takes option ``choice``.

    A stand-in for the cabin, for tests and for trying the way back without it: the files and the events are
    those of AgV Lab's ``StudyRecorder``, the ride itself is made up. Give a situation dict, a path to the
    exact file, or the name of a cabin scene. For a ride with ``traffic``, give the path to its recording.
    For a single choice, ``choice_route_seconds`` defaults to the trigger. To model revisions, give
    ``choice_attempts`` as pairs of option index and route seconds. At levels 0 and 1 the cabin answers
    automatically on recorded traffic. At other levels, no attempts means the rider leaves it unanswered.
    """
    folder = Path(directory)
    folder.mkdir(parents=True, exist_ok=True)
    data = None
    if isinstance(situation, Path) or (isinstance(situation, str) and situation not in CABIN_SCENARIOS):
        data = Path(situation).read_bytes()
        situation = json.loads(data)
    own_scene = isinstance(situation, str)
    if data is None and not own_scene:
        data = (json.dumps(situation, indent=1, ensure_ascii=False) + "\n").encode("utf-8")
    scenario = situation if own_scene else situation["cabin"]["scenario"]
    labels = CABIN_SCENARIOS[scenario][2] if own_scene else [o["label"] for o in situation["cabin"]["options"]]
    mark = hashlib.sha256(f"{scenario if own_scene else situation['id']}|{choice}|{agency}".encode()).hexdigest()
    session = f"00000000-0000-4000-8000-{mark[:12]}"
    asks = agency >= CABIN_ASKS_FROM
    base = {"scenario": scenario} if own_scene else {"scenario": scenario, "situation": situation["id"]}
    events = [("session_start", 0.0, 0.0, {"source": "mac_preview"}),
              ("scenario_reset", 0.5, 0.0, {**base, "agency": f"AgV-{agency}"}),
              ("route_start", 2.0, 0.0, {}),
              ("scenario_triggered", 22.0, 20.0, {**base, "agency": f"AgV-{agency}",
                                                  "stage": "awaiting_choice" if asks else "resolved"})]
    if choice is not None and asks and traffic is None:
        details = {**base, "choice_index": str(choice), "choice": labels[choice],
                   "control": "agent_plan" if in_conversation else f"scenario_choice_{choice}"}
        if in_conversation:
            details["previous_choice"] = "none"
        events.append(("scenario_choice", 31.5, 20.0 if in_conversation else 29.5, details))
    events += [("route_complete", 100.0, 98.0, {"destination": "city_gardens", "completed_stops": "city_gardens"}),
               ("session_finish", 101.0, 98.0, {})]
    meta = {"schemaVersion": 1, "sessionID": session, "participantCode": participant, "condition": "STAND-IN",
            "source": "mac_preview", "startedAtUTC": "2026-01-01T00:00:00.000Z", "finishedAtUTC": "2026-01-01T00:01:41.000Z",
            "stimulusVersion": "P6", "routeID": "stand-in", "routeDurationSeconds": 98.0, "scenario": scenario,
            "agency": agency, "status": "completed", "eventCount": len(events), "headPoseCount": 0}
    files = {}
    if traffic is not None:
        if own_scene:
            raise ValueError("a stand-in session with traffic needs its matching situation")
        if choice_attempts is not None and (choice is not None or choice_route_seconds is not None):
            raise ValueError("give either a single stand-in choice or choice_attempts")
        if choice is None and choice_route_seconds is not None:
            raise ValueError("choice_route_seconds needs a stand-in choice")
        attempts = list(choice_attempts or ())
        if choice is not None:
            seconds = situation["cabin"]["trigger_seconds"] if choice_route_seconds is None else choice_route_seconds
            attempts = [(choice, seconds)]
        events, traffic_meta, files = _stand_in_traffic(situation, data, traffic, attempts, agency, in_conversation)
        mark = hashlib.sha256(f"{mark}|{participant}|{in_conversation}|{traffic_meta['trafficSHA256']}|{attempts}".encode()).hexdigest()
        session = f"00000000-0000-4000-8000-{mark[:12]}"
        meta.update(traffic_meta, sessionID=session, eventCount=len(events), finishedAtUTC=_stand_in_timestamp(events[-1][1]))
    elif choice_attempts is not None or choice_route_seconds is not None:
        raise ValueError("stand-in choice times require a traffic recording")
    if data is not None:                    # the cabin keeps the situation it played, as it was loaded
        files["situation.json"] = data
        meta.update(situationID=situation["id"], situationSHA256=hashlib.sha256(data).hexdigest())
    for name, content in files.items():
        (folder / name).write_bytes(content)
    (folder / "metadata.json").write_text(json.dumps(meta, sort_keys=True), encoding="utf-8")
    with open(folder / "events.ndjson", "w", encoding="utf-8") as fh:
        for sequence, (event, elapsed, route_seconds, details) in enumerate(events):
            fh.write(json.dumps({"schemaVersion": 1, "sessionID": session, "sequence": sequence,
                                 "timeUTC": _stand_in_timestamp(elapsed if traffic is not None else 0), "elapsedSeconds": elapsed,
                                 "routeSeconds": route_seconds, "event": event, "details": details}, sort_keys=True) + "\n")
    return folder


# --------------------------------------------------------------------------- a person's choice in place of the agent's


def _cabin_answer(record: dict):
    outcome = record.get("outcome", {})
    if outcome.get("traffic"):
        return outcome["carried_out"]["answer"] if record.get("approval", {}).get("by") is not None else None
    return record.get("chose", {}).get("answer")


def answers(cabin_records: list) -> dict:
    """``{(agent, tick): action}`` for the records that answer a decision point of the network simulation."""
    out = {}
    for record in cabin_records:
        answer = _cabin_answer(record)
        if record.get("about") and answer is not None:
            _run, agent, tick = record["about"].rsplit("/", 2)
            program = record["who"].get("stand_in")
            rationale = "chosen in the cabin by a program" if program else "chosen by a person in the cabin"
            outcome = record.get("outcome", {})
            if outcome.get("traffic") and record.get("chose", {}).get("answer") is None:
                if outcome.get("late_choices"):
                    who = "a program" if program else "a person"
                    rationale = f"chosen too late by {who} in the cabin. The default was carried out"
                else:
                    who = "the program" if program else "the person"
                    rationale = f"not answered by {who} in the cabin. The default was carried out"
            out[(agent, int(tick))] = {"action": answer["action"], "args": dict(answer.get("args") or {}),
                                       "rationale": f"{rationale} ({record['id']})"}
    return out


def apply(source, cabin_records: list) -> dict:
    """Run the recorded run again with the cabin's answers in place of the simulated agents' at those points.

    Everything else is as it was: the same scenario, seed and decision models (so the rest of the run is the
    same up to there if they are built-in models, or a language model replayed from a cassette). Returns the
    result of the new run and, for every decision point answered, the record as it was and as it is now.

    A cabin answer belongs to the decision point the rider was shown. For an asked rider in a recorded-traffic
    ride it is the action carried out, including the default for a late-only or unanswered choice. A record
    that names a decision point this run does not have, or that shows different observations, is refused.
    """
    from .config import Config
    from .engine import Simulation

    records = _trace(source)
    header = records[0]
    given = answers(cabin_records)
    if not given:
        raise ValueError("none of the records answers a decision point of the network simulation")
    was = from_trace(records)
    points = {r["id"]: r for r in was}
    for record in cabin_records:
        if not record.get("about") or _cabin_answer(record) is None:
            continue
        point = points.get(record["about"])
        if point is None:
            raise ValueError(f"'{record['about']}' is not a decision point of this run")
        shown = {k: v for k, v in record.get("sees", {}).items() if k != "told"}
        if json.dumps(shown, sort_keys=True) != json.dumps(point.get("sees"), sort_keys=True):
            raise ValueError(f"at '{record['about']}' this run does not show what the rider was told: it is not the run "
                             "the situation was exported from, or it was recorded without what the agents saw")
    data = dict(header["config"])
    data["plugins"] = header.get("plugins", [])
    cfg = Config.from_dict(data)
    cfg.record.dir = None
    result = Simulation(cfg, answers=given).run()
    key = lambda record: (record["who"]["decides"], record["from"]["tick"])       # noqa: E731
    before = {key(r): r for r in was if key(r) in given}
    after = {key(r): r for r in from_trace(result.records) if key(r) in given}
    return {"result": result, "points": [{"agent": agent, "tick": tick, "before": before.get((agent, tick)),
                                          "after": after.get((agent, tick))} for agent, tick in sorted(given)]}
