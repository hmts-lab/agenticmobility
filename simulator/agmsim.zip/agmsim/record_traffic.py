"""Interpret AgV Lab's recorded-traffic events on the ride clock."""
from __future__ import annotations

import hashlib
import json
import math
import re
from dataclasses import dataclass, field

from .traffic_check import CHOICE_LEAD_SECONDS, FORMAT, check_recording_size

EPSILON = 1e-9  # the cabin includes the deadline, allowing this floating-point margin


def _require(condition, message):
    if not condition:
        raise ValueError(f"traffic session: {message}")


def _integer(value, where):
    if isinstance(value, str) and re.fullmatch(r"[0-9]{1,9}", value):
        value = int(value)
    _require(type(value) is int and value >= 0, f"invalid {where}")
    return value


def _seconds(value, where):
    try:
        time = float(value) if not isinstance(value, bool) else math.nan
    except (TypeError, ValueError, OverflowError):
        time = math.nan
    _require(math.isfinite(time) and time >= 0, f"invalid {where}")
    return time


def _sha(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


@dataclass
class TrafficSession:
    id: str
    sha256: str
    trigger: float
    default: int
    slot_count: int = 0
    slots: dict = field(default_factory=dict)  # slot index -> (release, deadline)
    arrivals: dict = field(default_factory=dict)  # (option, slot) -> recorded arrival
    loaded: bool = False
    current: tuple | None = None

    @property
    def initial(self):
        return self.default, self.slot_count - 1

    def note_slot(self, slot, time, deadline):
        time = _seconds(time, "slot time")
        deadline = _seconds(deadline, "slot deadline")
        prior = self.slots.get(slot)
        _require(0 <= slot < self.slot_count and deadline >= self.trigger
                 and time == round(deadline + CHOICE_LEAD_SECONDS, 2) and deadline == round(deadline, 2),
                 "invalid slot time or deadline")
        if prior is not None:
            _require(prior == (time, deadline), f"slot {slot} timing differs from the recorded ride")
        else:
            _require(all((other < slot and other_time < time) or (other > slot and other_time > time)
                         for other, (other_time, _) in self.slots.items()), "slot times are out of order")
            self.slots[slot] = (time, deadline)


def load_traffic(folder, meta, situation, situation_sha):
    """Bind the traffic stimulus to the session and its exact situation bytes."""
    path = folder / "traffic.json"
    traffic_id, digest = meta.get("trafficID"), meta.get("trafficSHA256")
    kept = path.exists()
    if not (kept or traffic_id is not None or digest is not None
            or meta.get("vehicleMotionVersion") == "recorded-traffic-v1"):
        return None
    _require(situation is not None and _sha(situation_sha)
             and meta.get("situationID") == situation.get("id") and meta.get("situationSHA256") == situation_sha,
             "the recorded traffic requires the exact situation file named in metadata.json")
    _require(traffic_id == situation["id"] + ".traffic" and _sha(digest),
             "metadata.json has an invalid trafficID or trafficSHA256")
    closed = meta.get("trafficClosedEdges")
    _require(closed is None or isinstance(closed, list) and all(isinstance(edge, str) for edge in closed),
             "metadata.json has invalid trafficClosedEdges")
    cabin = situation["cabin"]
    options = cabin["options"]
    default = next((i for i, option in enumerate(options) if option["answer"] == situation.get("default")), None)
    _require(default is not None, "the situation's default does not name a traffic option")
    trigger = _seconds(cabin.get("trigger_seconds", 20), "situation trigger")
    traffic = TrafficSession(traffic_id, digest, trigger, default)
    if not kept:
        return traffic

    check_recording_size(path.stat().st_size)
    data = path.read_bytes()
    _require(hashlib.sha256(data).hexdigest() == digest, "traffic.json SHA-256 differs from metadata.json")
    recording = json.loads(data.decode("utf-8"))
    _require(isinstance(recording, dict) and recording.get("format") == FORMAT
             and type(recording.get("version")) is int and recording["version"] == 1
             and recording.get("id") == traffic_id, "traffic.json format, version or ID differs")
    _require(recording.get("situation") == {"id": situation["id"], "sha256": situation_sha},
             "traffic.json does not name the exact situation and SHA-256")
    if closed is not None and "closed_edges" in recording:
        _require(recording.get("closed_edges") == closed,
                 "traffic.json closed edges differ from metadata.json")
    branch = recording.get("branch")
    _require(isinstance(branch, dict) and branch.get("trigger") == trigger and branch.get("default") == default,
             "traffic.json trigger or default differs from the situation")
    slots = branch.get("slots")
    _require(isinstance(slots, list) and bool(slots) and all(isinstance(x, dict) for x in slots),
             "traffic.json has invalid slots")
    traffic.slot_count = len(slots)
    for slot, values in enumerate(slots):
        traffic.note_slot(slot, values.get("time"), values.get("decide_by"))
    rides = recording.get("rides")
    _require(isinstance(rides, list) and len(rides) == len(slots) * len(options),
             "traffic.json needs a ride for every option and slot")
    origin = cabin.get("journey", {}).get("origin")
    for i, ride in enumerate(rides):
        slot, option = divmod(i, len(options))
        nodes = ride.get("nodes") if isinstance(ride, dict) else None
        _require(isinstance(nodes, list) and len(nodes) >= 2 and nodes[0] == origin
                 and nodes[-1:] == options[option].get("journey", {}).get("stops")
                 and ride.get("option") == option and ride.get("slot") == slot
                 and ride.get("label") == options[option]["label"], "traffic.json ride differs from its situation option")
        arrival = _seconds(ride.get("arrives"), "ride arrival")
        _require(arrival >= traffic.slots[slot][0], "traffic.json ride arrives before its slot")
        traffic.arrivals[option, slot] = arrival
    return traffic


def _loaded(traffic, details, meta, option_count):
    _require(not traffic.loaded and details.get("id") == traffic.id and details.get("sha256") == traffic.sha256,
             "traffic_loaded ID or SHA-256 differs from metadata.json")
    count = _integer(details.get("slots"), "traffic_loaded slots")
    _require(count > 0 and (not traffic.slot_count or count == traffic.slot_count)
             and _integer(details.get("rides"), "traffic_loaded rides") == count * option_count,
             "traffic_loaded ride or slot count differs")
    if meta.get("trafficClosedEdges") is not None and "closed_edges" in details:
        _require(details.get("closed_edges") == ",".join(meta["trafficClosedEdges"]),
                 "traffic_loaded closed edges differ from metadata.json")
    traffic.slot_count = count
    traffic.loaded = True


def _ride(traffic, details, option_count, *, choice=False):
    option_key, slot_key = ("carried_out_option", "carried_out_slot") if choice else ("option", "slot")
    id_key = "traffic_id" if choice else "id"
    option = _integer(details.get(option_key), option_key)
    slot = _integer(details.get(slot_key), slot_key)
    _require(traffic.loaded and details.get(id_key) == traffic.id and option < option_count
             and slot < traffic.slot_count, "event names an unknown traffic ride")
    traffic.note_slot(slot, details.get("slot_time"), details.get("decide_by"))
    return option, slot


def _choice(traffic, event, pending, options):
    details = event["details"]
    time = _seconds(event["routeSeconds"], "choice routeSeconds")
    option = _integer(details.get("choice_index"), "choice_index")
    _require(option < len(options) and details.get("choice") == options[option]["label"],
             "choice label or index differs from its situation option")
    control = details.get("control")
    _require(control in ("agent_plan", "traffic_default", f"scenario_choice_{option}"),
             "choice control differs from its attempted option")
    actual = _ride(traffic, details, len(options), choice=True)
    _require(traffic.current is not None and traffic.current[1] in traffic.slots
             and time >= traffic.trigger - EPSILON, "choice has no active traffic ride or precedes the trigger")
    if control == "traffic_default":
        _require(option == traffic.default and abs(time - traffic.trigger) <= EPSILON,
                 "automatic traffic choice differs from the default or trigger")

    late = time > traffic.slots[traffic.current[1]][1] + EPSILON
    _require(details.get("too_late") == ("true" if late else "false"),
             "choice too_late disagrees with the active slot deadline")
    if late:
        _require(control != "traffic_default" and "slot" not in details and pending is None
                 and actual == traffic.current, "late choice changed the traffic ride")
    else:
        slot = _integer(details.get("slot"), "choice slot")
        _require(actual == (option, slot) and time <= traffic.slots[slot][1] + EPSILON
                 and all(time > deadline + EPSILON for earlier, (_, deadline) in traffic.slots.items() if earlier < slot),
                 "timely choice did not select the first accepting slot for its option")
        if actual != traffic.current:
            _require(pending is not None and pending == (actual, time, control),
                     "choice differs from its traffic_ride_changed event")
        else:
            _require(pending is None, "unchanged choice has an unexpected traffic_ride_changed event")
        traffic.current = actual
    return late, time


def traffic_outcome(events, meta, situation, traffic):
    """Return timely choice rows, late attempts, and the verified resulting ride."""
    options = situation["cabin"]["options"]
    timely, late = [], []
    pending = asked = None
    restarting = False
    for event in events:
        kind, details = event["event"], event["details"]
        if kind == "traffic_loaded":
            _loaded(traffic, details, meta, len(options))
        elif kind == "traffic_refused":
            raise ValueError("traffic session: traffic_refused contradicts an active recording")
        elif kind == "route_reset":
            _require(pending is None and traffic.current is not None,
                     "restart has no current ride or interrupts a ride change")
            restarting = traffic.current != traffic.initial
            traffic.current = traffic.initial
        elif kind == "traffic_ride_changed":
            ride = _ride(traffic, details, len(options))
            reason = details.get("reason")
            time = _seconds(event["routeSeconds"], "ride change routeSeconds")
            _require(pending is None, "ride change has no corresponding choice")
            if reason == "session_start":
                route_id, initial_id = details.get("route_id"), meta.get("routeID")
                _require(traffic.current is None and (time > EPSILON or ride == traffic.initial)
                         and (route_id is None or initial_id is None or route_id == initial_id),
                         "initial traffic ride differs from the session or default")
                traffic.current = ride
            elif reason == "restart":
                _require(restarting and time == 0 and ride == traffic.initial,
                         "restart did not return to the default ride")
                restarting = False
            else:
                _require(not restarting and traffic.current is not None, "ride change precedes the initial or restarted ride")
                pending = ride, time, reason
        elif kind == "scenario_triggered":
            _require(traffic.current is not None and not restarting
                     and abs(_seconds(event["routeSeconds"], "trigger routeSeconds") - traffic.trigger) <= EPSILON,
                     "scenario trigger disagrees with the traffic recording")
            asked = event
        elif kind == "scenario_choice":
            _require(not restarting, "choice follows an unrecorded restart")
            too_late, time = _choice(traffic, event, pending, options)
            pending = None
            if too_late:
                attempt = {"option": int(details["choice_index"]), "label": details["choice"], "route_seconds": time,
                           "elapsed_seconds": _seconds(event["elapsedSeconds"], "choice elapsedSeconds")}
                if asked is not None:
                    elapsed = _seconds(asked["elapsedSeconds"], "trigger elapsedSeconds")
                    attempt["seconds_after_asked"] = round(attempt["elapsed_seconds"] - elapsed, 1)
                late.append(attempt)
            else:
                timely.append(event)
        elif kind == "route_complete":
            _require(traffic.current is not None and pending is None and not restarting, "arrival has no active traffic ride")
            option, slot = traffic.current
            target = options[option]["journey"]["stops"][-1]
            time = _seconds(event["routeSeconds"], "arrival routeSeconds")
            arrival = traffic.arrivals.get(traffic.current)
            _require(details.get("destination", target) == target and details.get("completed_stops", target) == target
                     and (arrival is None or abs(time - arrival) <= EPSILON)
                     and time >= traffic.slots[slot][0] - EPSILON, "arrival differs from the carried-out traffic ride")
    _require(pending is None, "ride change has no corresponding choice")
    if traffic.current is None or traffic.current[1] not in traffic.slots:
        return timely, late, {}
    option, slot = traffic.current
    release, deadline = traffic.slots[slot]
    result = {"traffic": {"id": traffic.id, "sha256": traffic.sha256},
              "carried_out": {"option": option, "label": options[option]["label"], "answer": options[option]["answer"],
                              "slot": slot, "slot_time": release, "decide_by": deadline},
              "late_choices": late}
    return timely, late, result
