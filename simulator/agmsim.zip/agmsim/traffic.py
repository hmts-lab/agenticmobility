"""Traffic as queues: what a road lets out, what it holds, and how a full road blocks the one behind it.

``network.traffic: queue`` (the other model, ``density``, slows a road by the vehicles on it and lets
any number in). Here every road has

* an **exit capacity** -- the vehicles per hour and lane that can leave it (at a traffic light: its
  saturation flow, while it has green);
* a **storage** -- the vehicles that fit on it bumper to bumper.

A vehicle drives along a road at the free speed (as incidents and the weather leave it), then waits at
its end, first come first served, until the exit has capacity for it and the next road has room. A road
that is full lets nobody in, so its queue grows back onto the road behind it: spillback. Room that opens
at the front of a full road reaches its entrance only once the gap has travelled back along the queue,
at the speed of the backward wave: one vehicle spacing per ``REACTION_SECONDS``, about 17 km/h. With the
free speed and the jam density that makes a triangular fundamental diagram, whose own capacity -- about
1800 vehicles per hour and lane at 50 km/h, 2000 at 90 km/h -- is the most a road takes in; its exit
capacity may be lower (lights along the way, a merge).

This is the link transmission model (Newell's simplified kinematic-wave theory; Yperman 2007) applied
to single vehicles -- the same theory as MATSim's queue model with holes and as UXsim. It gives the
travel times of that theory exactly as far as the time step allows; where a vehicle stands within its
road is only drawn (:meth:`QueueTraffic.shown_offset`).

``network.capacity_scale`` < 1 means one simulated vehicle stands for 1/scale real ones: capacity and
storage shrink by it, speeds and the backward wave do not.

What a road's travel time is *taken to be* by those who may know it (``Link.flow``, the share of its free
speed) follows from the same picture: whoever drives onto it now leaves it no sooner than the vehicles
already on it have been let out, one per headway of its exit.
"""
from __future__ import annotations

from collections import deque

from .network import MIN_FACTOR, StopLine

SLOWEST = 0.01          # the lowest share of its free speed a road is taken to move at
REACTION_SECONDS = 1.5  # a gap in a queue moves back by one vehicle spacing in this time (Newell's car-following)


class QueueTraffic:
    def __init__(self, net, cfg, dt: float):
        self.net, self.dt = net, float(dt)
        scale, spacing = float(cfg.capacity_scale), float(cfg.jam_spacing_m)
        default = float(cfg.lane_capacity_vph) / 3600.0
        self.now = 0
        self.stuck_ticks = max(1, int(round(float(cfg.stuck_seconds) / self.dt)))
        self.gates: list[StopLine] = []
        self.slots: list[float] = []            # vehicles that fit on each link
        self.wave: list[int] = []               # ticks a gap takes from the front of each link to its entrance
        back = spacing / REACTION_SECONDS                               # backward wave, m/s
        for link in net.links:
            per_lane = link.capacity or default                         # real vehicles per second and lane
            self.gates.append(StopLine(credit=1.0, rate=per_lane * link.lanes * scale))
            self.slots.append(float(max(1, round(link.length * link.lanes / spacing * scale))))
            self.wave.append(max(1, int(round(link.length / back / self.dt))))
        n = len(net.links)
        self.occ = [0.0] * n                    # vehicles on each link (a bus counts as two), and those let onto it
        self.gap_units = [0.0] * n              # room freed at the front that has not reached the entrance yet
        self.gaps = [deque() for _ in range(n)]     # ... as (tick it gets there, vehicles)
        self.load: dict[str, float] = {}        # mover -> the room it takes up on the road it is on
        self.reserved: dict[str, int] = {}      # mover let through its stop line -> the road that keeps room for it
        # movers at a junction that want to set off onto a link, first come first: (mover, the room it needs)
        self.origin: list[list] = [[] for _ in range(n)]
        self.origin_turn = [0.0] * n            # second at which the first of them is due its turn (see ``tick``)
        self.origin_blocked = [0] * n           # ticks in a row the first of them has found the link full
        self.listed: dict[str, int] = {}        # mover waiting to set off -> the link it waits for
        self.granted: dict[str, tuple] = {}     # mover told it may set off -> (link, the room kept for it)
        self._queued: set = set()               # links with movers at their stop line
        self._setting_off: set = set()          # links with movers waiting to set off onto them
        self._gapped: set = set()               # links with gaps under way
        # what happened, per link, for the table of roads
        self.queue_max = [0] * n                # most movers held at its end at once
        self.held_ticks = [0] * n               # mover-ticks spent held at its end
        self.blocked_ticks = [0] * n            # ticks its front mover found the next road full (spillback)
        self.forced = [0] * n                   # movers let onto it although it was full (kept out for stuck_seconds)
        self.origin_ticks = [0] * n             # mover-ticks spent waiting to set off onto it
        self.occ_max = [0.0] * n                # most vehicles it held at once
        self.through: dict[int, list] = {}      # hour of the run -> movers its stop line let through in that hour
        self._ticked = -1

    # ------------------------------------------------------------------ room on a road

    def room(self, link_id: int, pce: float) -> bool:
        return self.occ[link_id] + self.gap_units[link_id] + pce <= max(self.slots[link_id], pce) + 1e-9

    def _take(self, link_id: int, pce: float) -> None:
        self.occ[link_id] += pce
        if self.occ[link_id] > self.occ_max[link_id]:
            self.occ_max[link_id] = self.occ[link_id]

    def _through(self, link_id: int) -> None:
        """A mover was let through the stop line of ``link_id`` (counted by the hour, to hold against its capacity)."""
        hour = self.through.get(self.net.hour)
        if hour is None:
            hour = self.through[self.net.hour] = [0] * len(self.gates)
        hour[link_id] += 1

    def _leave(self, link_id: int, m) -> None:
        self.net.left[link_id] += 1
        pce = self.load.pop(m.id, 0.0)
        if pce:
            self.occ[link_id] = max(0.0, self.occ[link_id] - pce)
            self.gaps[link_id].append((self.now + self.wave[link_id], pce))
            self.gap_units[link_id] += pce
            self._gapped.add(link_id)

    def _unqueue(self, link_id: int, m) -> None:
        """The mover no longer waits here (its trip ends at this junction, or it has a way of its own)."""
        if m.queued:
            gate = self.gates[link_id]
            if gate.queue and gate.queue[0] is m:
                gate.blocked = 0
            gate.queue.remove(m)
            m.queued = False
            if not gate.queue:
                self._queued.discard(link_id)
        if m.go:
            m.go = False
            held = self.reserved.pop(m.id, None)
            if held is not None:
                self.occ[held] = max(0.0, self.occ[held] - self.load.get(m.id, 0.0))

    def _start(self, link_id: int, m, pce: float) -> bool:
        """May a mover setting off from a junction drive onto its first road? If not it waits in line for it."""
        granted = self.granted.pop(m.id, None)
        if granted is not None:
            if granted[0] == link_id:                   # ``tick`` kept room for it
                self.load[m.id] = pce
                return True
            self.occ[granted[0]] = max(0.0, self.occ[granted[0]] - granted[1])     # it sets off another way after all
        if self.listed.get(m.id) == link_id:
            return False
        queue = self.origin[link_id]
        if not queue and self.room(link_id, pce):
            self._take(link_id, pce)
            self.load[m.id] = pce
            self.origin_turn[link_id] = max(self.origin_turn[link_id], self.now * self.dt) + pce / self.gates[link_id].rate
            return True
        queue.append((m, pce))                          # (if it was in line for another link, that entry lapses)
        self.listed[m.id] = link_id
        self._setting_off.add(link_id)
        return False

    def _cross(self, link_id: int, nxt: int, m, pce: float) -> bool:
        """May the mover at the end of ``link_id`` drive on onto ``nxt`` now? If not it waits in line."""
        gate = self.gates[link_id]
        if m.go:                                        # let through by ``tick``: room on the next road is kept for it
            m.go = False
            held = self.reserved.pop(m.id, None)
            if held == nxt:
                return True
            if held is not None:                        # it has changed its mind about where to go
                self.occ[held] = max(0.0, self.occ[held] - pce)
            if self.room(nxt, pce):
                self._take(nxt, pce)
                return True
            gate.queue.insert(0, m)
            m.queued = True
            self._queued.add(link_id)
            return False
        if m.queued:
            return False
        self._refresh(link_id, self.now)
        if gate.green and not gate.queue and gate.credit >= 1.0 - 1e-9 and self.room(nxt, pce):
            gate.credit -= pce
            gate.passed += 1
            self._through(link_id)
            gate.turn = max(gate.turn, self.now * self.dt) + pce / gate.rate
            self._take(nxt, pce)
            return True
        gate.queue.append(m)
        m.queued = True
        self._queued.add(link_id)
        return False

    # ------------------------------------------------------------------ once per tick, before anything moves

    def _refresh(self, link_id: int, now: int) -> None:
        """Build up what the stop line may let through, for the ticks since this was last done.

        An incident or bad weather cuts what a road lets out as it cuts its speed (``Link.factor``, ``Link.ambient``).
        """
        gate = self.gates[link_id]
        if gate.stamp < now:
            if gate.green:
                link = self.net.links[link_id]
                per_tick = gate.rate * max(link.factor * link.ambient, MIN_FACTOR) * self.dt
                # an idle stop line saves up one vehicle's worth, and the fraction beyond it is not lost:
                # otherwise a headway would be rounded up to whole ticks and the road let out less than it can
                gate.credit = min(gate.credit + per_tick * (now - gate.stamp), 1.0 + per_tick)
            gate.stamp = now

    def refresh(self, link_id: int, now: "int | None" = None) -> None:
        """Bring a stop line up to date: before its light or the condition of its road changes."""
        self._refresh(link_id, self.now if now is None else now)

    def tick(self, now: int) -> None:
        """Gaps arrive at entrances; stop lines let through who is first, as capacity and room ahead allow."""
        if now == self._ticked:
            return
        self._ticked = self.now = now
        for link_id in sorted(self._gapped):
            gaps = self.gaps[link_id]
            while gaps and gaps[0][0] <= now:
                self.gap_units[link_id] -= gaps.popleft()[1]
            if not gaps:
                self.gap_units[link_id] = 0.0
                self._gapped.discard(link_id)
        for link_id, pce in self.granted.values():      # leave to set off that was not used lapses
            self.occ[link_id] = max(0.0, self.occ[link_id] - pce)
        self.granted.clear()
        # Where roads merge, and where vehicles set off onto a road others are driving on, the one whose turn is
        # longest overdue goes first. A turn comes round as often as the road's capacity allows (for those setting
        # off: the capacity of the road they set off onto), so they share the room ahead in proportion to it.
        gates, turns = self.gates, self.origin_turn
        sources = [(gates[i].turn, 0, i) for i in self._queued] + [(turns[i], 1, i) for i in self._setting_off]
        for _turn, setting_off, link_id in sorted(sources):
            if setting_off:
                self._admit(link_id, now)
            else:
                self._release(link_id, now)
        self._estimate()

    def _admit(self, link_id: int, now: int) -> None:
        """Movers waiting at the start of ``link_id`` set off onto it, first come first, as it has room."""
        queue = self.origin[link_id]
        self.origin_ticks[link_id] += len(queue)
        while queue:
            m, pce = queue[0]
            if self.listed.get(m.id) != link_id or m.link is not None or not m.path or m.path[0] != link_id:
                queue.pop(0)                            # it has gone another way, or nowhere
                if self.listed.get(m.id) == link_id:
                    del self.listed[m.id]
                continue
            if not self.room(link_id, pce):
                self.origin_blocked[link_id] += 1
                if self.origin_blocked[link_id] < self.stuck_ticks:
                    break
                self.forced[link_id] += 1
            queue.pop(0)
            del self.listed[m.id]
            self.origin_blocked[link_id] = 0
            self._take(link_id, pce)
            self.granted[m.id] = (link_id, pce)
            self.origin_turn[link_id] = max(self.origin_turn[link_id], now * self.dt) + pce / self.gates[link_id].rate
        if not queue:
            self._setting_off.discard(link_id)

    def _release(self, link_id: int, now: int) -> None:
        gate = self.gates[link_id]
        self._refresh(link_id, now)
        self.queue_max[link_id] = max(self.queue_max[link_id], len(gate.queue))
        self.held_ticks[link_id] += len(gate.queue)
        while gate.queue:
            m = gate.queue[0]
            if len(m.path) < 2:                         # its trip now ends here: it needs neither green nor room
                gate.queue.pop(0)
                m.queued, gate.blocked = False, 0
                continue
            if not gate.green or gate.credit < 1.0 - 1e-9:
                break
            pce, nxt = self.load.get(m.id, 1.0), m.path[1]
            if not self.room(nxt, pce):
                gate.blocked += 1
                if self.occ[nxt] + pce > max(self.slots[nxt], pce) + 1e-9:     # full of vehicles, not just of gaps under way
                    self.blocked_ticks[link_id] += 1
                if gate.blocked < self.stuck_ticks:
                    break
                self.forced[nxt] += 1
            gate.queue.pop(0)
            m.queued, m.go, gate.blocked = False, True, 0
            gate.credit -= pce
            gate.released += 1
            self._through(link_id)
            gate.turn = max(gate.turn, now * self.dt) + pce / gate.rate
            self._take(nxt, pce)
            self.reserved[m.id] = nxt
        if not gate.queue:
            self._queued.discard(link_id)

    def _estimate(self) -> None:
        """What each road's travel time is taken to be: ``Link.flow``, the share of its free speed it moves at.

        Whoever drives onto a road now leaves it no sooner than at the free speed, and no sooner than the
        vehicles already on it have been let out: one per headway of its exit (longer while the next road is full).
        """
        net, changed = self.net, False
        for link in net.links:
            ahead = self.occ[link.id]
            flow = 1.0
            if ahead > 0:
                gate = self.gates[link.id]
                condition = max(link.factor * link.ambient, MIN_FACTOR)
                headway = 1.0 / (gate.rate * gate.share * condition)
                if gate.blocked:
                    headway = max(headway, gate.blocked * self.dt)
                if gate.credit >= 1.0 - 1e-9:
                    ahead -= 1.0                        # the first of them goes at once
                free = link.length / (link.speed * condition)
                if ahead * headway > free:
                    flow = max(SLOWEST, round(free / (ahead * headway), 3))
            if abs(flow - link.flow) > 1e-9:
                link.flow, changed = flow, True
        if changed:
            net.version += 1
            net._dynamic_trees.clear()

    # ------------------------------------------------------------------ movement

    def advance(self, m, dt: float, factor: float = 1.0, free: bool = False, pce: float = 1.0) -> tuple[float, bool]:
        """Move ``m`` along ``m.path`` for ``dt`` seconds; ``free``: it has a lane and a green of its own.

        Returns the metres travelled and whether the end of the path was reached.
        """
        net = self.net
        budget, moved = dt, 0.0
        while m.path and budget > 1e-9:
            link = net.links[m.path[0]]
            if m.link is None:                              # setting off from a junction
                if not free and not self._start(link.id, m, pce):
                    break
                m.link, m.offset = link.id, 0.0
                net.count_entry(link.id)
            speed = link.speed * max(link.factor * link.ambient, MIN_FACTOR) * factor
            remaining = link.length - m.offset
            need = remaining / speed
            if need > budget + 1e-9:
                step = speed * budget
                m.offset += step
                moved += step
                break
            moved += remaining
            m.offset = link.length
            if free or len(m.path) == 1:                    # nothing holds it at the end of this road
                self._unqueue(link.id, m)
                self._leave(link.id, m)
                budget -= need
                m.node, m.link, m.offset = link.v, None, 0.0
                m.path.pop(0)
                continue
            nxt = m.path[1]
            if not self._cross(link.id, nxt, m, pce):
                break
            budget -= need
            self._leave(link.id, m)
            self.load[m.id] = pce
            m.path.pop(0)
            m.node, m.link, m.offset = link.v, nxt, 0.0
            net.count_entry(nxt)
        return moved, (not m.path and m.link is None)

    # ------------------------------------------------------------------ for drawing, fingerprints and tables

    def shown_offset(self, m) -> float:
        """Where on its road to draw the mover: a queue stands back from the stop line, and nobody drives through it."""
        link = self.net.links[m.link]
        gate = self.gates[m.link]
        if not gate.queue:
            return m.offset
        each = link.length / self.slots[m.link]             # road length one waiting vehicle takes up
        if m.queued:
            before = 0
            for other in gate.queue:
                if other is m:
                    break
                before += 1
            return max(0.0, link.length - before * each)
        return min(m.offset, max(0.0, link.length - len(gate.queue) * each))

    def state(self) -> tuple:
        """The part of the system state kept here, for the run's fingerprint."""
        out = []
        for link_id, gate in enumerate(self.gates):
            if self.occ[link_id] or self.gaps[link_id] or gate.queue or gate.credit != 1.0:
                out.append((link_id, round(self.occ[link_id], 3), round(gate.credit, 6), gate.blocked,
                            tuple(m.id for m in gate.queue), tuple(self.gaps[link_id])))
        lines = tuple((link_id, self.origin_blocked[link_id], tuple(m.id for m, _pce in self.origin[link_id]))
                      for link_id in sorted(self._setting_off))
        return tuple(out), tuple(sorted(self.reserved.items())), lines, tuple(sorted(self.granted.items()))

    def totals(self) -> dict:
        dt = self.dt
        return {
            "queue_max": max(self.queue_max, default=0),                 # most vehicles held at the end of one road at once
            "held_hours": round(sum(self.held_ticks) * dt / 3600.0, 3),  # vehicle hours spent held at the end of a road
            "waiting_to_set_off_hours": round(sum(self.origin_ticks) * dt / 3600.0, 3),   # ... and before a first road with no room
            "spillback_s": round(sum(self.blocked_ticks) * dt, 1),       # road-seconds whose front vehicle found the next road full
            "roads_that_spilled_back": sum(1 for b in self.blocked_ticks if b),
            "let_in_though_full": sum(self.forced),                      # vehicles kept out for stuck_seconds, then let in
        }
