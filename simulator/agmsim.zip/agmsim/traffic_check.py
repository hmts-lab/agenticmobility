"""Geometry and validation for an offline cabin traffic recording."""
from __future__ import annotations

import math
import re
from dataclasses import dataclass

FORMAT = "agmsim-cabin-traffic"
TRAFFIC_RATES, EGO_RATE = (5, 10), 30
CHOICE_LEAD_SECONDS = 3
LANE_OFFSET, TURN_RADIUS, INTERSECTION_HALF = 1.8, 12.0, 15.0
TRAFFIC_POSE_DIGITS = (2, 2, 3, 2)
EGO_POSE_DIGITS = (4, 4, 3, 2, 4)
FRAME = {
    "units": "meters",
    "origin": "n1_0",
    "x": "east",
    "z": "south",
    "yaw": "radians, zero north, positive toward west",
    "row": "vehicle box center x, z, yaw, speed in m/s",
    "ego_row": "vehicle box center x, z, yaw, speed in m/s, cumulative distance in meters",
    "lane_offset_m": LANE_OFFSET,
    "turn_radius_m": TURN_RADIUS,
    "intersection_half_width_m": INTERSECTION_HALF,
}
MAX_RECORDING_BYTES = 8_000_000


def check_recording_size(size):
    if size > MAX_RECORDING_BYTES:
        raise ValueError(f"traffic recording exceeds the cabin's 8 MB limit (at least {size:,} bytes). "
                         "Export with a larger --decision-step or fewer --decision-seconds.")


def _require(condition, message):
    if not condition:
        raise ValueError(message)


@dataclass(frozen=True)
class LanePiece:
    """One straight or quarter-circle of the cabin's lane centerline."""

    x: float
    z: float
    dx: float
    dz: float
    length: float
    outgoing: tuple[float, float] | None = None

    def pose(self, distance):
        d = max(0.0, min(self.length, distance))
        if self.outgoing is None:
            return self.x + self.dx * d, self.z + self.dz * d, math.atan2(-self.dx, -self.dz)
        ox, oz = self.outgoing
        c, s = math.cos(d / TURN_RADIUS), math.sin(d / TURN_RADIUS)
        x = self.x + TURN_RADIUS * (ox * (1 - c) + self.dx * s)
        z = self.z + TURN_RADIUS * (oz * (1 - c) + self.dz * s)
        return x, z, math.atan2(-(self.dx * c + ox * s), -(self.dz * c + oz * s))

    def nearest(self, x, z):
        """Squared separation and distance along this piece to its nearest point."""
        if self.outgoing is None:
            distance = max(0.0, min(self.length, (x - self.x) * self.dx + (z - self.z) * self.dz))
        else:
            ox, oz = self.outgoing
            rx, rz = x - self.x - TURN_RADIUS * ox, z - self.z - TURN_RADIUS * oz
            along = rx * self.dx + rz * self.dz
            toward_start = -(rx * ox + rz * oz)
            if along >= 0 and toward_start >= 0:
                distance = TURN_RADIUS * math.atan2(along, toward_start)
            else:
                distance = 0.0 if along < toward_start else self.length
        px, pz, _ = self.pose(distance)
        return (x - px) ** 2 + (z - pz) ** 2, distance


def lane_pieces(points):
    """Reconstruct CityLayout's right-hand lanes and 12 m turns from the road nodes."""
    _require(len(points) >= 2, "ego path needs at least two nodes")
    directions = []
    for (ax, az), (bx, bz) in zip(points, points[1:]):
        dx, dz = bx - ax, bz - az
        _require((dx == 0) != (dz == 0), "ego path has a disconnected street segment")
        length = abs(dx) + abs(dz)
        directions.append((dx / length, dz / length))
    dx, dz = directions[0]
    current_x, current_z = points[0][0] - LANE_OFFSET * dz, points[0][1] + LANE_OFFSET * dx
    pieces = []
    for i, (x, z) in enumerate(points[1:]):
        dx, dz = directions[i]
        ox, oz = directions[i + 1] if i + 1 < len(directions) else (dx, dz)
        turn = (dx, dz) != (ox, oz)
        if turn:
            _require(dx * ox + dz * oz == 0, "ego path makes an instantaneous U-turn")
            ix, iz = x - LANE_OFFSET * (dz + oz), z + LANE_OFFSET * (dx + ox)
            end_x, end_z = ix - TURN_RADIUS * dx, iz - TURN_RADIUS * dz
        else:
            end_x, end_z = x - LANE_OFFSET * dz, z + LANE_OFFSET * dx
        length = (end_x - current_x) * dx + (end_z - current_z) * dz
        _require(length >= 0, "ego path cannot fit a 12 m turn")
        if length:
            pieces.append(LanePiece(current_x, current_z, dx, dz, length))
        if turn:
            pieces.append(LanePiece(end_x, end_z, dx, dz, TURN_RADIUS * math.pi / 2, (ox, oz)))
            current_x, current_z = ix + TURN_RADIUS * ox, iz + TURN_RADIUS * oz
        else:
            current_x, current_z = end_x, end_z
    return pieces


@dataclass(frozen=True)
class _Box:
    x: float
    z: float
    dx: float
    dz: float
    half_length: float
    half_width: float
    extent_x: float
    extent_z: float

    @classmethod
    def at(cls, row, length, width):
        x, z, yaw = row[:3]
        dx, dz = -math.sin(yaw), -math.cos(yaw)
        hl, hw = length / 2, width / 2
        return cls(x, z, dx, dz, hl, hw,
                   abs(dx) * hl + abs(dz) * hw, abs(dz) * hl + abs(dx) * hw)

    def radius_on(self, dx, dz):
        return (abs(self.dx * dx + self.dz * dz) * self.half_length
                + abs(-self.dz * dx + self.dx * dz) * self.half_width)

    def overlaps(self, other):
        """Separating-axis test for two oriented rectangles. Touching edges are allowed."""
        x, z = self.x - other.x, self.z - other.z
        if abs(x) >= self.extent_x + other.extent_x or abs(z) >= self.extent_z + other.extent_z:
            return False
        return all(abs(x * dx + z * dz) + 1e-9 < self.radius_on(dx, dz) + other.radius_on(dx, dz)
                   for dx, dz in ((self.dx, self.dz), (-self.dz, self.dx),
                                  (other.dx, other.dz), (-other.dz, other.dx)))


def _number(value, decimals=None):
    return (type(value) in (int, float) and -1e12 <= value <= 1e12
            and (decimals is None or round(value, decimals) == value))


def _text(value):
    return isinstance(value, str) and bool(value.strip())


def _object(value, where):
    _require(isinstance(value, dict), f"{where} must be an object")
    return value


def _array(value, where):
    _require(isinstance(value, list), f"{where} must be an array")
    return value


def _time(value, where):
    _require(_number(value, 2) and value >= 0, f"{where} must be a nonnegative time rounded to 0.01 s")
    return value


def _dimensions(vehicle, where):
    length, width = vehicle.get("length"), vehicle.get("width")
    _require(_number(length, 2) and _number(width, 2) and length > 0 and width > 0,
             f"{where} has invalid box dimensions")
    return length, width


def _row(row, where, precision=TRAFFIC_POSE_DIGITS):
    _require(isinstance(row, list) and len(row) == len(precision)
             and all(_number(value, digits) for value, digits in zip(row, precision))
             and row[3] >= 0, f"{where} has an invalid pose row")


def _interpolate(track, tick, stride):
    index, part = divmod(tick, stride)
    a = track[index]
    if part == 0:
        return a
    b = track[index + 1]
    weight = part / stride
    yaw = a[2] + weight * math.remainder(b[2] - a[2], math.tau)
    return (a[0] + (b[0] - a[0]) * weight, a[1] + (b[1] - a[1]) * weight,
            yaw, a[3] + (b[3] - a[3]) * weight)


def _check_boxes(ego, dimensions, vehicles, stopped_at, stride, where):
    # Traffic is interpolated on the 30 Hz ego clock.
    # Only cars near each other in x reach the oriented-box test.
    moving = [tick for tick, row in enumerate(ego) if row[3] > 0]
    for tick, row in enumerate(ego):
        boxes = [("ego", _Box.at(row, *dimensions), row[3])]
        for name, _kind, start, size, track in vehicles:
            offset = tick - start * stride
            if 0 <= offset <= (len(track) - 1) * stride:
                pose = _interpolate(track, offset, stride)
                boxes.append((name, _Box.at(pose, *size), pose[3]))
        boxes.sort(key=lambda item: item[1].x - item[1].extent_x)
        for i, (name, box, speed) in enumerate(boxes):
            for other_name, other, _ in boxes[i + 1:]:
                if other.x - other.extent_x >= box.x + box.extent_x:
                    break
                if box.overlaps(other):
                    raise ValueError(f"{where}: boxes overlap at {tick / EGO_RATE:.2f} s ({name}, {other_name})")
            ego_waits = (name == "ego" and moving and moving[0] < tick < moving[-1]
                         and (ego[tick - 1][3] == 0 or ego[tick + 1][3] == 0))
            if speed == 0 and (name != "ego" or ego_waits):
                for junction in stopped_at:
                    if box.overlaps(junction):
                        raise ValueError(f"{where}: {name} waits inside an intersection at {tick / EGO_RATE:.2f} s")


def _points(frame, field):
    points = _object(frame.get(field), f"frame.{field}")
    for name, point in points.items():
        _require(_text(name) and isinstance(point, (list, tuple)) and len(point) == 2
                 and all(_number(value) for value in point), f"frame.{field} has an invalid point")
    return {name: tuple(point) for name, point in points.items()}


def _corridor(a, b, width):
    x, z = a
    tx, tz = b
    pad_x, pad_z = (width, 0) if x == tx else (0, width)
    return min(x, tx) - pad_x, max(x, tx) + pad_x, min(z, tz) - pad_z, max(z, tz) + pad_z


def _frame(recording):
    frame = _object(recording.get("frame"), "frame")
    _require(all(frame.get(key) == value for key, value in FRAME.items()), "frame conventions are invalid")
    intersections = _points(frame, "intersections")
    midblocks = _points(frame, "midblocks")
    places = _points(frame, "places")
    points = {**intersections, **midblocks, **places}
    _require(len(points) == len(intersections) + len(midblocks) + len(places)
             and intersections.get("n1_0") == (0, 0), "frame needs unique nodes and n1_0 at (0, 0)")
    _require(all(point in midblocks.values() for point in places.values()), "frame place is not on a midblock")
    streets = []
    for edge in _array(frame.get("streets"), "frame.streets"):
        _require(isinstance(edge, list) and len(edge) == 2 and all(_text(node) and node in points for node in edge)
                 and not any(node in places for node in edge), "frame has an unknown street")
        a, b = (points[node] for node in edge)
        _require((a[0] == b[0]) != (a[1] == b[1]), "frame has a disconnected street segment")
        streets.append((a, b))
    _require(bool(streets), "frame needs at least one street")

    # A corridor follows the road surface, with a wider 30 m square at each intersection.
    corridors = [_corridor(a, b, 5) for a, b in streets]
    corridors += [(x - INTERSECTION_HALF, x + INTERSECTION_HALF, z - INTERSECTION_HALF, z + INTERSECTION_HALF)
                  for x, z in intersections.values()]
    gateways = _points(frame, "gateways")
    xs, zs = zip(*intersections.values())
    for name, direction in gateways.items():
        _require(name in intersections, "frame gateway must be an intersection")
        x, z = intersections[name]
        if z == max(zs):
            outward = (0, 1)
        elif z == min(zs):
            outward = (0, -1)
        elif x == min(xs):
            outward = (-1, 0)
        else:
            outward = (1, 0) if x == max(xs) else None
        _require(direction == outward, "frame gateway must point outside the grid")
        dx, dz = direction
        corridors.append(_corridor((x, z), (x + 60 * dx, z + 60 * dz), 5))
    return intersections, points, streets, corridors


def _street_covers(a, b, streets):
    """Whether connected road segments span the straight leg, including its midblocks."""
    if (a[0] == b[0]) == (a[1] == b[1]):
        return False
    fixed = 0 if a[0] == b[0] else 1
    axis = 1 - fixed
    remaining, end = sorted((a[axis], b[axis]))
    intervals = sorted(sorted((p[axis], q[axis])) for p, q in streets if p[fixed] == q[fixed] == a[fixed])
    for low, high in intervals:
        if low <= remaining < high:
            remaining = high
    return remaining >= end


def _ego_path(ego, points, streets, where):
    _require(all(_street_covers(a, b, streets) for a, b in zip(points, points[1:])),
             f"{where}: route leaves the streets")
    pieces = lane_pieces(points)
    _require(bool(pieces), f"{where}: ego path has zero length")
    previous = None
    previous_advance = None
    chord_distance = 0.0
    for tick, row in enumerate(ego):
        at = f"{where} ego at {tick / EGO_RATE:.2f} s"
        _row(row, at, EGO_POSE_DIGITS)
        x, z, _, speed, distance = row
        _require(any(piece.nearest(x, z)[0] <= 1.0 for piece in pieces),
                 f"{where}: ego is more than 1 m from its lane at {tick / EGO_RATE:.2f} s")
        if previous is None:
            _require(distance == 0, f"{at}: cumulative distance must start at zero")
        else:
            _require(abs(round(speed * 100) - round(previous[3] * 100)) <= 5,
                     f"{at}: speed acceleration exceeds 1.5 m/s²")
            advance = distance - previous[4]
            _require(advance >= 0, f"{at}: cumulative distance decreases")
            chord_distance += math.hypot(x - previous[0], z - previous[1])
            _require(abs(distance - chord_distance) <= 0.005 + 1e-9,
                     f"{at}: cumulative distance differs from the path length by more than 5 mm")
            _require(abs(speed - advance * EGO_RATE) <= 0.05 + 1e-9,
                     f"{at}: speed differs from the rate of change of distance by more than 0.05 m/s")
            if previous_advance is not None:
                _require(abs(advance - previous_advance) * EGO_RATE ** 2 <= 1.5 + 1e-7,
                         f"{at}: distance acceleration exceeds 1.5 m/s²")
            previous_advance = advance
        previous = row
    for row, piece, distance in ((ego[0], pieces[0], 0), (ego[-1], pieces[-1], pieces[-1].length)):
        x, z, _ = piece.pose(distance)
        _require(math.hypot(row[0] - x, row[1] - z) <= 1, f"{where}: ego misses a journey endpoint")


def _vehicles(entries, arrival_tick, corridors, rate, where):
    vehicles = []
    names = set()
    for vehicle in _array(entries, f"{where}.vehicles"):
        _object(vehicle, f"{where}.vehicle")
        name, kind = vehicle.get("id"), vehicle.get("kind")
        _require(_text(name) and name != "ego" and name not in names and _text(kind),
                 f"{where}: vehicle id or kind is invalid")
        names.add(name)
        size = _dimensions(vehicle, f"{where} vehicle {name}")
        start_time = _time(vehicle.get("from"), f"{where} vehicle {name} from")
        start = round(start_time * rate)
        _require(start_time == start / rate, f"{where}: vehicle {name} starts off the {rate} Hz clock")
        track = _array(vehicle.get("track"), f"{where} vehicle {name} track")
        _require(0 < len(track) <= arrival_tick // (EGO_RATE // rate) - start + 1,
                 f"{where}: vehicle {name} track exceeds the ride clock or is empty")
        for row in track:
            _row(row, f"{where} vehicle {name}")
            x, z, _, _ = row
            _require(any(lo_x <= x <= hi_x and lo_z <= z <= hi_z for lo_x, hi_x, lo_z, hi_z in corridors),
                     f"{where}: vehicle {name} is outside the road bounds")
        vehicles.append((name, kind, start, size, track))
    return vehicles


def _through_tick(time, rate):
    # Recover the sample boundary from the rounded timestamp.
    return math.floor((time + 0.005) * rate + 1e-9)


def _prefix(ego, vehicles, time, rate):
    until = _through_tick(time, rate)
    return (ego[:_through_tick(time, EGO_RATE) + 1],
            {name: (kind, start, size, track[:until - start + 1])
             for name, kind, start, size, track in vehicles if start <= until})


def _slots(branch):
    trigger = _time(branch.get("trigger"), "branch.trigger")
    times = []
    for index, slot in enumerate(_array(branch.get("slots"), "branch.slots")):
        where = f"branch slot {index}"
        _object(slot, where)
        time = _time(slot.get("time"), f"{where}.time")
        deadline = _time(slot.get("decide_by"), f"{where}.decide_by")
        _require(time == round(deadline + CHOICE_LEAD_SECONDS, 2) and deadline >= trigger,
                 f"{where}: deadline must be at least the trigger time and 3 seconds before release")
        _require(not times or time > times[-1], f"{where}: release times must increase")
        times.append(time)
    _require(bool(times), "branch needs at least one slot")
    return times


def check_traffic(recording):
    """Check a decoded v1 recording without SUMO. Raise ValueError on the first failure."""
    _object(recording, "traffic recording")
    _require(recording.get("format") == FORMAT and type(recording.get("version")) is int
             and recording["version"] == 1, "unknown traffic format or version")
    situation = _object(recording.get("situation"), "situation")
    name, sha = situation.get("id"), situation.get("sha256")
    _require(_text(name) and recording.get("id") == f"{name}.traffic" and isinstance(sha, str)
             and re.fullmatch("[a-f0-9]{64}", sha) is not None, "invalid situation id or SHA-256")
    source = _object(recording.get("from"), "from")
    _require(source.get("platform") == "agmsim" and all(_text(source.get(k)) for k in ("run", "clock", "simulator"))
             and source["simulator"].startswith("SUMO ") and type(source.get("tick")) is int
             and source["tick"] >= 0 and type(source.get("seed")) is int, "invalid AgMSim/SUMO provenance")
    place = _object(recording.get("place"), "place")
    _require(type(place.get("node")) is int and _text(place.get("name")) and _text(place.get("inside")),
             "invalid traffic place")
    _object(recording.get("state"), "state")
    closed = _array(recording.get("closed_edges"), "closed_edges")
    _require(all(_text(edge) for edge in closed) and len(set(closed)) == len(closed), "invalid closed_edges")
    rate = recording.get("rate")
    _require(type(rate) is int and rate in TRAFFIC_RATES
             and type(recording.get("ego_rate")) is int and recording["ego_rate"] == EGO_RATE,
             "traffic must use 5 or 10 Hz and ego must use 30 Hz")
    dimensions = _dimensions(_object(recording.get("ego"), "ego"), "ego")
    intersections, points, streets, corridors = _frame(recording)

    branch = _object(recording.get("branch"), "branch")
    branch_node = branch.get("node")
    _require(_text(branch_node) and branch_node in intersections, "invalid branch node")
    _require("time" not in branch and "decide_by" not in branch, "branch timings belong in branch.slots")
    times = _slots(branch)
    rides = _array(recording.get("rides"), "rides")
    option_count, unmatched = divmod(len(rides), len(times))
    _require(option_count >= 2 and not unmatched, "every slot needs a ride for each of at least two options")
    default = branch.get("default")
    _require(type(default) is int and 0 <= default < option_count, "branch default must name an option")
    routes = []
    checked = []
    x, z = intersections[branch_node]
    junctions = [_Box.at((x, z, 0, 0), 2 * INTERSECTION_HALF, 2 * INTERSECTION_HALF)
                 for x, z in intersections.values()]
    for index, ride in enumerate(rides):
        slot, option = divmod(index, option_count)
        where = f"slot {slot} ride {option}"
        _object(ride, where)
        label = ride.get("label")
        _require(type(ride.get("slot")) is int and ride["slot"] == slot
                 and type(ride.get("option")) is int and ride["option"] == option and _text(label),
                 f"{where}: rides must be ordered by slot and option and have a label")
        nodes = _array(ride.get("nodes"), f"{where}.nodes")
        _require(len(nodes) >= 2 and all(_text(n) and n in points for n in nodes), f"{where}: unknown route node")
        if slot == 0:
            routes.append(nodes)
        else:
            _require(nodes == routes[option] and label == rides[option]["label"],
                     f"{where}: option route or label differs between slots")
        arrives = _time(ride.get("arrives"), f"{where}.arrives")
        ego = _array(ride.get("ego"), f"{where}.ego")
        arrival_tick = len(ego) - 1
        time = times[slot]
        _require(arrival_tick > 0 and arrives == round(arrival_tick / EGO_RATE, 2) and time <= arrives,
                 f"{where}: ego rows disagree with arrival or slot time")
        _ego_path(ego, [points[n] for n in nodes], streets, where)
        branch_ego = _through_tick(time, EGO_RATE)
        _require(max(abs(ego[branch_ego][0] - x), abs(ego[branch_ego][1] - z)) <= INTERSECTION_HALF + 5,
                 f"{where}: ego is away from the branch at the slot time")
        vehicles = _vehicles(ride.get("vehicles"), arrival_tick, corridors, rate, where)
        checked.append((ego, vehicles))
        _check_boxes(ego, dimensions, vehicles, junctions, EGO_RATE // rate, where)

    # Agreement through each ride's own release with one latest-slot ride
    # implies agreement for every pair through their earlier release.
    reference_ego, reference_vehicles = checked[(len(times) - 1) * option_count + default]
    prefixes = [_prefix(reference_ego, reference_vehicles, time, rate) for time in times]
    for index, (ego, vehicles) in enumerate(checked):
        slot, option = divmod(index, option_count)
        _require(_prefix(ego, vehicles, times[slot], rate) == prefixes[slot],
                 f"slot {slot} ride {option}: rides differ through the slot time")

    _require(any(route != routes[0] for route in routes[1:]), "the rides have no distinct continuations")
    last_common = None
    for nodes in zip(*routes):
        if len(set(nodes)) != 1:
            break
        if nodes[0] in intersections:
            last_common = nodes[0]
    _require(last_common == branch_node, "branch is not the last common intersection")
