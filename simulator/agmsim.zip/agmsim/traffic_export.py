"""Build a SUMO district and export the traffic around a cabin decision point."""
from __future__ import annotations

import hashlib
import heapq
import itertools
import json
import math
import random
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

from . import gmns, record
from .traffic_check import (EGO_RATE, FORMAT, FRAME, INTERSECTION_HALF as JUNCTION_HALF, LANE_OFFSET,
                            TRAFFIC_RATES, TURN_RADIUS, check_recording_size, lane_pieces)

GATEWAY_LENGTH = 60
DIRECTIONS = [(0, -1), (1, 0), (0, 1), (-1, 0)]  # north, east, south, west in the cabin
EGO = {"length": 4.4, "width": 1.85}
WARMUP = 420
DEMAND_END = 1500


class District:
    def __init__(self, inside: gmns.Inside):
        if "n1_0" not in inside.nodes:
            raise ValueError("the inside network needs n1_0 as the cabin's origin")
        self.inside = inside
        x0, y0, _ = inside.nodes["n1_0"]
        self.points = {n: (round(x - x0, 4), round(y0 - y, 4)) for n, (x, y, _) in sorted(inside.nodes.items())}
        self.intersections = {n for n, (_, _, kind) in inside.nodes.items() if kind == "intersection"}
        self.streets = {n: [] for n in self.points}
        self.street_edges = {}
        for id_, a, b, _ in sorted(inside.links):
            if self.points[a] == self.points[b] or all(p != q for p, q in zip(self.points[a], self.points[b])):
                raise ValueError(f"cabin street {id_} needs to be straight and aligned to the grid")
            self.streets[a].append(b)
            self.streets[b].append(a)
            self.street_edges[f"{a}__{b}"] = (a, b)
            self.street_edges[f"{b}__{a}"] = (b, a)
        xs, zs = zip(*self.points.values())
        self.gateways = {}
        for n in sorted(set(inside.gateways.values())):
            x, z = self.points[n]
            # Corners use the north/south street, like the cabin's access planner.
            if z == max(zs):
                heading = 0
            elif z == min(zs):
                heading = 2
            elif x == min(xs):
                heading = 1
            elif x == max(xs):
                heading = 3
            else:
                raise ValueError(f"cabin gateway {n} is not on the edge of the district")
            self.gateways[n] = heading

    def endpoint(self, name, *, arriving):
        if name in self.gateways:
            return name, (self.gateways[name] + (2 if arriving else 0)) % 4
        if name not in self.inside.places:
            raise ValueError(f"unknown cabin journey endpoint {name!r}")
        poi = self.inside.places[name]
        nx, ny, _ = self.inside.nodes[poi["node"]]
        x, z = ny - poi["north"], nx - poi["east"]
        return poi["node"], _heading(x, z)

    def path(self, start, stop):
        """Find a shortest route with the cabin's lane access and turn costs."""
        source, heading = self.endpoint(start, arriving=False)
        target, access = self.endpoint(stop, arriving=True)
        queue = [(0, source, heading, (source,))]
        best = {(source, heading): 0}
        while queue:
            cost, node, direction, path = heapq.heappop(queue)
            if cost > best[node, direction]:
                continue
            if (node, direction) == (target, access) and len(path) > 1:
                return list(path)
            x, z = self.points[node]
            for nxt in sorted(self.streets[node]):
                nx, nz = self.points[nxt]
                turn = _heading(nx - x, nz - z)
                if turn == (direction + 2) % 4 or (len(path) == 1 and start in self.gateways and turn != direction):
                    continue
                score = cost + math.hypot(nx - x, nz - z) + (2 if turn != direction else 0)
                if score < best.get((nxt, turn), math.inf):
                    best[nxt, turn] = score
                    heapq.heappush(queue, (score, nxt, turn, (*path, nxt)))
        raise ValueError(f"no cabin route from {start} to {stop} in their access lanes")

    def route(self, start, stop, path):
        edges = [f"{a}__{b}" for a, b in zip(path, path[1:])]
        if start in self.gateways:
            edges.insert(0, f"in_{start}")
        if stop in self.gateways:
            edges.append(f"out_{stop}")
        return edges

    def frame(self):
        return {**FRAME,
                "intersections": {n: list(p) for n, p in self.points.items() if n in self.intersections},
                "gateways": {n: [-k for k in DIRECTIONS[h]] for n, h in self.gateways.items()},
                "places": {n: list(self.points[p["node"]]) for n, p in sorted(self.inside.places.items())},
                "midblocks": {n: list(p) for n, p in self.points.items() if n not in self.intersections},
                "streets": [list(sorted((a, b))) for _, a, b, _ in sorted(self.inside.links)]}


def _heading(x, z):
    return (1 if x > 0 else 3) if abs(x) > abs(z) else (2 if z > 0 else 0)


def _sumo_shape(points):
    return " ".join(f"{x:.6f},{-z:.6f}" for x, z in points)


def _junction_shape(p, incoming, outgoing):
    """The straight lane or the same 12 m fillet the cabin uses for a turn."""
    x, z = p
    dx, dz = incoming
    ex, ez = outgoing
    half = JUNCTION_HALF
    begin = (x - dx * half - dz * LANE_OFFSET, z - dz * half + dx * LANE_OFFSET)
    end = (x + ex * half - ez * LANE_OFFSET, z + ez * half + ex * LANE_OFFSET)
    if incoming == outgoing:
        return [begin, end]
    r = TURN_RADIUS
    sx = x - (dz + ez) * LANE_OFFSET - r * dx
    sz = z + (dx + ex) * LANE_OFFSET - r * dz
    angles = [math.pi * i / 48 for i in range(25)]
    arc = [(sx + r * (dx * math.sin(a) + ex * (1 - math.cos(a))),
            sz + r * (dz * math.sin(a) + ez * (1 - math.cos(a)))) for a in angles]
    return [begin, *arc, end]


def _xml(folder, name, root):
    ET.ElementTree(root).write(folder / name, encoding="utf-8", xml_declaration=True)


def write_network(folder, district, state):
    """Write netconvert inputs. External roads extend 60 m past their gateways."""
    points = dict(district.points)
    edges = dict(district.street_edges)
    approach_speed = {f"in_{g['node']}": round(max(2, 6 * g["inbound"]["speed_ratio"]), 2)
                      for g in state["gateways"]}
    for n, heading in district.gateways.items():
        x, z = points[n]
        dx, dz = DIRECTIONS[heading]
        outer = f"ext_{n}"
        points[outer] = (x - GATEWAY_LENGTH * dx, z - GATEWAY_LENGTH * dz)
        edges[f"in_{n}"] = (outer, n)
        edges[f"out_{n}"] = (n, outer)
    xml_nodes, xml_edges, xml_connections = ET.Element("nodes"), ET.Element("edges"), ET.Element("connections")
    incoming, outgoing = {n: [] for n in points}, {n: [] for n in points}
    for n, (x, z) in points.items():
        args = {"id": n, "x": str(x), "y": str(-z), "type": "priority"}
        if n in district.intersections:
            h = JUNCTION_HALF
            args.update(type="allway_stop", shape=_sumo_shape([(x-h, z-h), (x-h, z+h), (x+h, z+h), (x+h, z-h)]))
        ET.SubElement(xml_nodes, "node", args)
    for id_, (a, b) in sorted(edges.items()):
        px, pz = points[a]
        qx, qz = points[b]
        heading = _heading(qx - px, qz - pz)
        incoming[b].append((id_, heading))
        outgoing[a].append((id_, heading))
        ET.SubElement(xml_edges, "edge", {"id": id_, "from": a, "to": b, "numLanes": "1", "width": "3.6",
                                         "spreadType": "right", "speed": str(approach_speed.get(id_, 6))})
    for n in sorted(points):
        for (a, enter), (b, leave) in itertools.product(incoming[n], outgoing[n]):
            if (enter + 2) % 4 == leave:
                continue
            args = {"from": a, "to": b, "fromLane": "0", "toLane": "0"}
            if n in district.intersections:
                shape = _junction_shape(points[n], DIRECTIONS[enter], DIRECTIONS[leave])
                args.update(shape=_sumo_shape(shape), speed="6" if enter == leave else "3")
            ET.SubElement(xml_connections, "connection", args)
    _xml(folder, "district.nod.xml", xml_nodes)
    _xml(folder, "district.edg.xml", xml_edges)
    _xml(folder, "district.con.xml", xml_connections)


def build_network(netconvert, folder):
    result = subprocess.run([netconvert, "--node-files", "district.nod.xml", "--edge-files", "district.edg.xml",
                             "--connection-files", "district.con.xml", "--output-file", "district.net.xml",
                             "--offset.disable-normalization", "--no-turnarounds", "--precision", "6"],
                            cwd=folder, capture_output=True, text=True)
    if result.returncode:
        raise ValueError(f"netconvert failed: {result.stderr.strip()}")


def closed_gateways(state):
    return [f"{prefix}_{g['node']}" for g in state["gateways"]
            for direction, prefix in (("inbound", "in"), ("outbound", "out")) if g[direction]["closed"]]


def write_demand(folder, district, state, seed, *, onward_delay=0.0):
    """Scale observed movement rates to a miniature and meter its slower exits."""
    gates = {g["node"]: g for g in state["gateways"]}
    closed = set(closed_gateways(state))
    projected_delay = {}
    for option in state["option_routes"]:
        n = option["gateway"]
        if n in gates:
            projected_delay[n] = min(projected_delay.get(n, math.inf), option["onward_delay_seconds"])
    service = {}
    for n, g in gates.items():
        ratio = max(0.05, g["outbound"]["speed_ratio"])
        # Ten seconds is the free-flow crossing time of a 60 m gateway approach.
        gate_delay = 10 * (1 / ratio - 1)
        release = round(min(75, max(gate_delay, onward_delay * projected_delay.get(n, 0))), 1)
        if release >= 1:
            service[n] = release

    source_totals = {}
    for m in state["movements"]:
        source_totals[m["from"]] = source_totals.get(m["from"], 0) + m["count"]
    rng = random.Random(seed)
    departures, rates = [], []
    for m in state["movements"]:
        a, b = m["from"], m["to"]
        if a == b or f"in_{a}" in closed or f"out_{b}" in closed or not m["count"]:
            continue
        start = a or district.inside.place("departures")
        stop = b or district.inside.place("arrivals")
        if start is None or stop is None or start == stop:
            continue
        path = district.path(start, stop)
        # Smoothly saturate the single-lane district's inflow as city load increases.
        # For local trips the 30-minute movement count supplies the same relative load.
        load = gates[a]["inbound"]["entries_per_nominal_exit_capacity"] if a else source_totals[a] / 6
        rate = 0.045 * load / (1 + load) * m["count"] / source_totals[a]
        if not rate:
            continue
        rates.append({"from": a, "to": b, "vehicles_per_minute": round(rate * 60, 4)})
        edges = " ".join(district.route(start, stop, path))
        interval = 1 / rate
        depart = rng.random() * interval
        while depart < DEMAND_END:
            departures.append((round(depart, 1), edges, b))
            depart += interval

    routes = ET.Element("routes")
    ET.SubElement(routes, "vType", {"id": "district-car", "vClass": "passenger", "length": "4.4", "width": "1.85",
                                    "maxSpeed": "6", "accel": "1.4", "decel": "2.5", "minGap": "2.6",
                                    "sigma": "0", "speedFactor": "1", "speedDev": "0", "jmStoplineGap": "0.2"})
    for i, (depart, edges, b) in enumerate(sorted(departures, key=lambda d: d[:2]), 1):
        v = ET.SubElement(routes, "vehicle", {"id": f"c{i}", "type": "district-car", "depart": str(depart)})
        ET.SubElement(v, "route", edges=edges)
        if b in service:
            # The lead car waits for a release on the model's continuation of that road.
            ET.SubElement(v, "stop", lane=f"out_{b}_0", endPos="16", duration=str(service[b]))
    _xml(folder, "district.rou.xml", routes)
    return {"warmup_seconds": WARMUP, "onward_delay": onward_delay, "movements": rates,
            "exit_release_seconds": service, "exit_stop_position_m": JUNCTION_HALF + 16}


def _journeys(district, cabin):
    start = cabin["journey"]["origin"]
    options = cabin["options"]
    if len(options) < 2 or any(len(o["journey"]["stops"]) != 1 for o in options):
        raise ValueError("traffic export needs at least two options with one stop each")
    stops = [o["journey"]["stops"][0] for o in options]
    paths = [district.path(start, stop) for stop in stops]
    common = [step[0] for step in itertools.takewhile(lambda step: len(set(step)) == 1, zip(*paths))]
    if len(common) < 2 or common[-1] not in district.intersections or all(path == common for path in paths):
        raise ValueError("the cabin options must branch at a shared intersection after the origin")
    nodes = [[start, *(n for n in path[1:-1] if n in district.intersections), stop]
             for path, stop in zip(paths, stops)]
    routes = [district.route(start, stop, path) for path, stop in zip(paths, stops)]
    for route, stop, path in zip(routes, stops, paths):
        if stop not in district.gateways:
            # A SUMO insertion/arrival position refers to the front bumper. Keep the
            # vehicle present until its center reaches the midblock destination.
            approach, target = path[-2:]
            beyond = next((n for n in district.streets[target] if n != approach), None)
            if beyond is None:
                raise ValueError(f"the cabin stop {stop} needs a through street")
            route.append(f"{target}__{beyond}")
    origin = district.points[paths[0][0]]
    destinations = [district.points[path[-1]] for path in paths]
    return routes, nodes, common[-1], (origin[0], -origin[1]), [(x, -z) for x, z in destinations]


def export_traffic(run, situation_path, inside_path, out, *, onward_delay=0.0, decision_seconds=30.0,
                   decision_step=10.0, rate=5):
    from .traffic_check import check_traffic
    from .traffic_state import extract_city_state
    from .traffic_sumo import find_sumo, simulate_rides

    if not 0 <= onward_delay <= 1:
        raise ValueError("--onward-delay must be a share between 0 and 1")
    if not math.isfinite(decision_seconds) or decision_seconds < 0:
        raise ValueError("--decision-seconds must be finite and nonnegative")
    if not math.isfinite(decision_step) or decision_step <= 0:
        raise ValueError("--decision-step must be finite and positive")
    if type(rate) is not int or rate not in TRAFFIC_RATES:
        raise ValueError("--rate must be 5 or 10")
    situation_path, out = Path(situation_path), Path(out)
    if out.resolve() == situation_path.resolve():
        raise ValueError("the recording needs a different file from the input situation")
    raw = situation_path.read_bytes()
    situation = json.loads(raw.decode("utf-8"))
    if situation.get("format") != record.FORMAT or situation.get("version") != record.VERSION:
        raise ValueError("the situation is not an AgMSim decision record")
    cabin = situation["cabin"]
    options = cabin["options"]
    default = situation.get("default")
    default_option = next((i for i, option in enumerate(options) if option["answer"] == default), None)
    if default is None or default_option is None:
        raise ValueError("the situation's default answer does not match any cabin option")
    net, inside = gmns.read(inside_path)
    place = cabin["place"]
    if inside is None or place != {"node": inside.node, "name": net.names.get(inside.node, ""), "inside": inside.name}:
        raise ValueError("the situation and the GMNS inside network name different places")
    district = District(inside)
    routes, nodes, branch_node, origin, destinations = _journeys(district, cabin)
    frame = district.frame()
    points = {**frame["intersections"], **frame["places"]}
    geometry = [lane_pieces([points[n] for n in path]) for path in nodes]
    sumo, netconvert = find_sumo()
    state = extract_city_state(run, situation, inside)
    closed = closed_gateways(state)
    if any(edge in closed for route in routes for edge in route):
        raise ValueError("a cabin option uses a gateway that was closed in the city run")
    seed = situation["from"]["seed"]
    with tempfile.TemporaryDirectory(prefix=".agmsim-traffic-", dir=out.resolve().parent) as tmp:
        folder = Path(tmp)
        write_network(folder, district, state)
        build_network(netconvert, folder)
        state["district"] = write_demand(folder, district, state, seed, onward_delay=onward_delay)
        state["district"]["decision_seconds"] = decision_seconds
        state["district"]["decision_step"] = decision_step
        version, branch, rides, hold_seconds = simulate_rides(
            sumo, folder, routes=routes, nodes=nodes, geometry=geometry, labels=[o["label"] for o in options],
            origin=origin, destinations=destinations, branch_node=branch_node, seed=seed,
            trigger_seconds=cabin["trigger_seconds"], default_option=default_option, decision_seconds=decision_seconds,
            decision_step=decision_step, rate=rate, warmup=WARMUP)
        state["district"]["slot_hold_seconds"] = hold_seconds
        from_ = situation["from"]
        recording = {"format": FORMAT, "version": 1, "id": situation["id"] + ".traffic",
                     "situation": {"id": situation["id"], "sha256": hashlib.sha256(raw).hexdigest()},
                     "from": {"platform": "agmsim", "run": from_["run"], "tick": from_["tick"], "clock": from_["clock"],
                              "simulator": version, "seed": seed},
                     "place": {k: place[k] for k in ("node", "name", "inside")}, "frame": frame, "state": state,
                     "closed_edges": closed, "rate": rate, "ego_rate": EGO_RATE, "ego": EGO, "branch": branch, "rides": rides}
        data = json.dumps(recording, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")
        check_recording_size(len(data))
        check_traffic(recording)
        staged = folder / "traffic.json"
        staged.write_bytes(data)
        staged.replace(out)
    return recording
