"""Measure a recorded city run at the decision shown in a cabin situation."""
from __future__ import annotations

from collections import Counter
from itertools import chain
from pathlib import Path

from . import record
from .config import Config
from .engine import Simulation
from .network import MIN_FACTOR
from .recorder import Recorder, read_trace

WINDOW_SECONDS = 1800


def _source(run, situation: dict) -> tuple:
    records = read_trace(run) if isinstance(run, (str, Path)) else run
    if not records or records[0].get("type") != "header":
        raise ValueError("the run trace does not start with a header")
    header = records[0]
    when, who = situation["from"], situation["who"]["decides"]
    tick, trigger = when["tick"], situation["trigger"]["name"]
    decision = next((row for row in records
                     if row["type"] == "decision" and row["tick"] == tick
                     and row["agent"] == who and row["trigger"] == trigger), None)
    if decision is not None:
        original, = record.from_trace([header, decision])
        if all(original.get(key) == situation.get(key) for key in ("id", "from", "sees")):
            checkpoint = next((row for row in reversed(records) if row["type"] == "state" and row["tick"] <= tick), None)
            return header, checkpoint
    raise ValueError("the recorded run does not contain the situation's decision and observations")


def _option_routes(net, situation: dict, district: int) -> list[dict]:
    """The advertised paths, and the actual city-wide congestion they encounter after the district."""
    context = situation["sees"].get("context", {})
    result = []
    for index, option in enumerate(situation["cabin"]["options"]):
        answer = option["answer"]
        action, args = answer["action"], answer.get("args", {})
        if action == "choose_route":
            route = next((row for row in context.get("routes", ()) if row["route"] == args.get("route")), {})
        elif action == "accept_suggestion":
            route = context.get("proposal", {})
        elif action == "decline_suggestion":
            route = context.get("if_you_stay_on_this_route", {})
        else:
            continue
        nodes = route.get("via_nodes")
        if not nodes or nodes[0] != district:
            continue
        links = [net.link_between(a, b) for a, b in zip(nodes, nodes[1:])]
        if any(link is None for link in links):
            raise ValueError(f"the city route for option {index} uses a road missing from the run")
        free = sum(link.free_time for link in links)
        current = sum(link.cur_time for link in links)
        slowest = max(links, key=lambda link: link.cur_time - link.free_time, default=None)
        bottleneck = None if slowest is None else {
            "link": slowest.id, "from": slowest.u, "to": slowest.v,
            "road": net.road_names.get((slowest.u, slowest.v), ""),
            "speed_ratio": round(slowest.cur_speed / slowest.speed, 4),
            "delay_seconds": round(slowest.cur_time - slowest.free_time, 2),
        }
        result.append({"option": index, "gateway": option["journey"]["stops"][-1],
                       "nodes": nodes, "shown_seconds": round(option["minutes"] * 60, 2),
                       "free_seconds": round(free, 2), "current_seconds": round(current, 2),
                       "delay_seconds": round(current - free, 2),
                       "onward_delay_seconds": round(sum(link.cur_time - link.free_time for link in links[1:]), 2),
                       "bottleneck": bottleneck})
    return result


def extract_city_state(run, situation: dict, inside) -> dict:
    """Re-run built-in models to sample flows and turns over the half hour before the decision."""
    header, checkpoint = _source(run, situation)
    cfg = Config.from_dict({**header["config"], "plugins": header.get("plugins", [])})
    for kind in cfg.active_kinds():
        agent = getattr(cfg.agents, kind)
        if agent.use_llm or any(group.get("use_llm") for group in agent.mix):
            raise ValueError("traffic export requires a city run using built-in decision models")
    sim = Simulation(cfg, recorder=Recorder(None, keep=False))
    try:
        return _sample(sim, situation, inside, checkpoint)
    finally:
        sim.close()


def _sample(sim: Simulation, situation: dict, inside, checkpoint: dict | None) -> dict:
    w = sim.world
    net, traffic = w.net, w.net.traffic
    tick = situation["from"]["tick"]
    if not 0 <= tick < sim.n_ticks:
        raise ValueError("the situation's tick is outside the city run")
    start = max(0, tick - w.ticks(WINDOW_SECONDS))
    duration = (tick - start) * w.dt
    inbound, outbound, pairs = {}, {}, {}
    for neighbor, gateway in sorted(inside.gateways.items()):
        into, out = net.link_between(neighbor, inside.node), net.link_between(inside.node, neighbor)
        if into is None or out is None:
            raise ValueError(f"gateway {gateway} names a road missing from the city run")
        inbound[into.id], outbound[out.id] = gateway, gateway
        pairs[neighbor] = into, out
    if not pairs:
        raise ValueError("the inside network has no gateways")
    gate_links = [link for pair in pairs.values() for link in pair]
    who = situation["who"]["decides"]
    ego = w.travelers[who].car if who in w.travelers else who

    def positions() -> dict:
        return {m.id: m.link for m in chain(w.vehicles.values(), w.cabs.values(), w.buses.values())
                if m.id != ego and (m.link in inbound or m.link in outbound)}

    def capacity(link) -> float:
        if traffic is not None:
            gate = traffic.gates[link.id]
            rate = gate.rate * gate.share
        else:
            default = sim.cfg.network.lane_capacity_vph / 3600
            rate = (link.capacity or default) * link.lanes * sim.cfg.network.capacity_scale
        return rate * max(link.factor * link.ambient, MIN_FACTOR)

    def verify() -> None:
        if checkpoint is not None and w.tick == checkpoint["tick"] and w.digest() != checkpoint["digest"]:
            raise ValueError(f"the city replay differs from the recorded run at tick {w.tick}")

    verify()
    while w.tick < start:
        sim.step()
        verify()
    entered, left = net.entered.copy(), net.left.copy()
    previous = positions()
    movements, speed_sum, capacity_sum = Counter(), Counter(), Counter()
    while w.tick < tick:
        sim.step()
        verify()
        for link in gate_links:
            speed_sum[link.id] += link.cur_speed / link.speed
            capacity_sum[link.id] += capacity(link) * w.dt
        current = positions()
        # A boundary movement is one change of link at the city tick resolution.
        # Montreal's gateway links take multiple ticks to drive, so the two directions are visible here.
        for mover in previous.keys() | current.keys():
            a, b = previous.get(mover), current.get(mover)
            if a != b and (a in inbound or b in outbound):
                movements[inbound.get(a), outbound.get(b)] += 1
        previous = current
    # Interventions scheduled for this tick apply before the agent is shown the situation.
    for intervention in sim._interventions.get(tick, ()):
        sim._apply_intervention(intervention)

    def direction(link) -> dict:
        ix = link.id
        cap = capacity_sum[ix]
        entries = net.entered[ix] - entered[ix]
        gate = traffic.gates[ix] if traffic is not None else net.stop_lines.get(ix)
        occupants = sum(m.link == ix for m in chain(w.vehicles.values(), w.cabs.values(), w.buses.values()))
        return {
            "link": ix, "entered": entries, "exited": net.left[ix] - left[ix],
            # The numerator includes trip endings and priority movements that bypass an exit stop line.
            "nominal_exit_capacity_vehicles": round(cap, 4),
            "entries_per_nominal_exit_capacity": round(entries / cap, 4) if cap else 0.0,
            "free_speed_mps": round(link.speed, 2), "speed_mps": round(link.cur_speed, 2),
            "speed_ratio": round(link.cur_speed / link.speed, 4),
            "mean_speed_ratio": round(speed_sum[ix] / (tick - start), 4) if duration else None,
            "occupancy": occupants, "storage": traffic.slots[ix] if traffic is not None else None,
            "queued": len(gate.queue) if gate is not None else 0,
            "closed": link.factor <= MIN_FACTOR,
        }

    gateways = []
    for neighbor, (into, out) in pairs.items():
        gateways.append({"node": inside.gateways[neighbor], "neighbor": neighbor,
                         "road": net.road_names.get((inside.node, neighbor), ""),
                         "leads_to": net.names.get(neighbor, str(neighbor)),
                         "inbound": direction(into), "outbound": direction(out)})
    totals = Counter()
    for (a, b), count in movements.items():
        totals[a] += count
    turns = [{"from": a, "to": b, "count": count, "share": round(count / totals[a], 6)}
             for (a, b), count in sorted(movements.items(), key=lambda row: (row[0][0] or "", row[0][1] or ""))]
    return {"window_start_tick": start, "window_end_tick": tick, "window_seconds": round(duration, 2),
            "capacity_scale": sim.cfg.network.capacity_scale, "traffic_model": sim.cfg.network.traffic,
            "gateways": gateways, "movements": turns, "option_routes": _option_routes(net, situation, inside.node)}
