"""Run SUMO and convert its floating-car output into cabin traffic tracks."""
from __future__ import annotations

import gzip
import importlib.util
import json
import math
import os
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
from bisect import bisect_right
from contextlib import contextmanager
from itertools import accumulate, takewhile
from pathlib import Path
from tempfile import TemporaryFile

from .traffic_check import CHOICE_LEAD_SECONDS, EGO_POSE_DIGITS, EGO_RATE, TRAFFIC_POSE_DIGITS, check_recording_size

LENGTH, WIDTH = 4.4, 1.85
NATIVE_RATE = 10
SIMULATION_LIMIT = 600  # seconds allowed for each stage to reach its endpoint
EGO_ID = "ego"


def find_sumo():
    """Find both optional executables without importing SUMO or adding a dependency."""
    package = importlib.util.find_spec("sumo")
    homes = []
    if os.environ.get("SUMO_HOME"):
        homes.append(Path(os.environ["SUMO_HOME"]))
    if package and package.origin:
        homes.append(Path(package.origin).parent)

    programs = []
    for name in ("sumo", "netconvert"):
        executable = shutil.which(name)
        if executable is None:
            executable = next((p for home in homes if (p := shutil.which(str(home / "bin" / name)))), None)
        if executable is None:
            raise ValueError(
                f"{name} was not found. Install Eclipse SUMO and add its bin directory to PATH, set SUMO_HOME, "
                "or run uv run --no-project --with eclipse-sumo --with pyyaml python -m agmsim.cli traffic export ..."
            )
        programs.append(str(Path(executable).absolute()))
    return tuple(programs)


def _pose(vehicle):
    # SUMO reports the front bumper and clockwise degrees from north. Move
    # back along the box's axis before changing to south and left-positive yaw.
    yaw = math.remainder(-math.radians(float(vehicle.get("angle"))), math.tau)
    x = float(vehicle.get("x")) + LENGTH / 2 * math.sin(yaw)
    z = -float(vehicle.get("y")) + LENGTH / 2 * math.cos(yaw)
    return (x, z, yaw, float(vehicle.get("speed")))


def _round_pose(pose, digits):
    return [round(value, precision) or 0 for value, precision in zip(pose, digits)]


def _piece_starts(geometry):
    return list(accumulate((piece.length for piece in geometry), initial=0.0))


def _ego_rows(frames, geometry, branch_index, branch_distance):
    """Integrate SUMO's speed profile and evaluate the cabin's exact lane path."""
    speeds = [frame[EGO_ID][3] for frame in frames]
    segments = list(zip(speeds, speeds[1:]))
    integrated = list(accumulate(((a + b) / (2 * NATIVE_RATE) for a, b in segments), initial=0.0))
    starts = _piece_starts(geometry)
    at_branch = integrated[branch_index]
    after_branch = integrated[-1] - at_branch
    if at_branch <= 0 or after_branch <= 0:
        raise ValueError("the SUMO ego vehicle must move before and after the branch")

    # SUMO gives point connectors at midblocks a finite length and represents
    # arcs by chords. Match the cabin's lengths separately on either side of
    # the stopped fork. Scaling speed and distance together preserves the
    # integral, stop times, and the common approach across all options.
    before_scale = branch_distance / at_branch
    after_scale = (starts[-1] - branch_distance) / after_branch
    x, z, yaw = geometry[0].pose(0)
    ego = [_round_pose((x, z, yaw, speeds[0] * before_scale, 0), EGO_POSE_DIGITS)]
    for tick, (low, high) in enumerate(segments):
        if tick < branch_index:
            base, scale = integrated[tick] * before_scale, before_scale
        else:
            base, scale = branch_distance + (integrated[tick] - at_branch) * after_scale, after_scale
        acceleration = (high - low) * NATIVE_RATE
        for sample in range(1, EGO_RATE // NATIVE_RATE + 1):
            elapsed = sample / EGO_RATE
            distance = base + (low + 0.5 * acceleration * elapsed) * elapsed * scale
            speed = (low + acceleration * elapsed) * scale
            index = min(bisect_right(starts, distance) - 1, len(geometry) - 1)
            x, z, heading = geometry[index].pose(distance - starts[index])
            yaw += math.remainder(heading - yaw, math.tau)
            ego.append(_round_pose((x, z, yaw, speed, distance), EGO_POSE_DIGITS))
    return ego


def _ride(option, slot, label, nodes, frames, geometry, branch_index, branch_distance, rate):
    """Serialize a contiguous sequence of 10 Hz SUMO observations."""
    ego = _ego_rows(frames, geometry, branch_index, branch_distance)
    tracks = {}
    for tick, frame in enumerate(frames[::NATIVE_RATE // rate]):
        for id_, pose in frame.items():
            if id_ == EGO_ID:
                continue
            if id_ not in tracks:
                tracks[id_] = {"id": id_, "kind": "car", "length": LENGTH, "width": WIDTH,
                               "from": round(tick / rate, 2), "track": []}
            track = tracks[id_]
            if round(track["from"] * rate) + len(track["track"]) != tick:
                raise ValueError(f"SUMO vehicle {id_} disappeared and reappeared")
            track["track"].append(_round_pose(pose, TRAFFIC_POSE_DIGITS))
    return {"option": option, "slot": slot, "label": label, "nodes": nodes,
            "arrives": round((len(frames) - 1) / NATIVE_RATE, 2),
            "ego": ego, "vehicles": [tracks[id_] for id_ in sorted(tracks)]}


def _observations(stream):
    """Yield the post-step floating-car frame, timestamped in SUMO's ticks."""
    events = ET.iterparse(stream, events=("start", "end"))
    _, root = next(events)
    for event, elem in events:
        if event == "end" and elem.tag == "timestep":
            ego = elem.find(f"vehicle[@id='{EGO_ID}']")
            tick = round(float(elem.get("time")) * NATIVE_RATE)
            frame = {vehicle.get("id"): _pose(vehicle) for vehicle in elem.iterfind("vehicle")}
            yield tick, frame, ego
            root.clear()


@contextmanager
def _run(sumo, folder, seed, *args):
    command = [sumo, "--net-file", "district.net.xml", "--step-length", str(1 / NATIVE_RATE),
               "--precision", "8", "--fcd-output", "stdout", "--fcd-output.attributes", "x,y,angle,speed,lane,pos",
               "--seed", str(seed), "--no-step-log", "--duration-log.disable", "--xml-validation", "never",
               "--time-to-teleport", "-1", "--collision.action", "warn", "--collision.check-junctions",
               "--collision.mingap-factor", "0", "--step-method.ballistic", *args]
    with TemporaryFile(dir=folder) as log, subprocess.Popen(
        command, cwd=folder, stdout=subprocess.PIPE, stderr=log
    ) as process:
        try:
            yield _observations(process.stdout)
        except (ET.ParseError, StopIteration) as exc:
            raise ValueError("SUMO did not produce readable floating-car observations") from exc
        finally:
            # The stage's endpoint is in the FCD stream. Closing the pipe
            # ends SUMO after that endpoint without simulating the unused horizon.
            process.stdout.close()
            status = process.wait()
            log.seek(0)
            report = log.read().decode("utf-8", "replace")
            if re.search(r"\bcollision\b", report, re.IGNORECASE):
                raise ValueError(f"SUMO reported a collision: {report.strip()}")
            if status not in (0, -13, 243):  # normal exit or closed stdout, with or without the wheel wrapper
                raise ValueError(f"SUMO failed: {report.strip() or f'exit {status}'}")


def _lane(net, edge):
    lane = net.find(f"edge[@id='{edge}']/lane")
    if lane is None:
        raise ValueError(f"SUMO network lacks edge {edge!r}")
    return lane


def _heading(lane):
    start, *_, end = [tuple(map(float, point.split(","))) for point in lane.get("shape").split()]
    dx, dy = (b - a for a, b in zip(start, end))
    distance = math.hypot(dx, dy)
    return dx / distance, dy / distance


def _branch_distance(lane, stop, geometry):
    """Locate the stationary box center at the approach stop line in the cabin."""
    x, y = map(float, lane.get("shape").split()[-1].split(","))
    dx, dy = _heading(lane)
    behind_end = float(lane.get("length")) - stop + LENGTH / 2
    x, z = x - dx * behind_end, -y + dy * behind_end
    starts = _piece_starts(geometry)
    projections = (piece.nearest(x, z) for piece in geometry)
    return min((offset, start + distance) for start, (offset, distance) in zip(starts, projections))[1]


def _forward(plane, direction, pose):
    x, y = plane
    dx, dy = direction
    return (pose[0] - x) * dx + (-pose[1] - y) * dy


def _endpoint_stop(net, incoming, outgoing, point):
    """Find the front-bumper position when the box center is at a journey endpoint."""
    direction = _heading(_lane(net, outgoing))
    connection = net.find(f"connection[@from='{incoming}'][@to='{outgoing}']")
    via = net.find(f".//lane[@id='{connection.get('via')}']") if connection is not None else None
    for lane in (via, _lane(net, outgoing)):
        if lane is None:
            continue
        shape = [tuple(map(float, p.split(","))) for p in lane.get("shape").split()]
        distance = (sum((q - p) * d for p, q, d in zip(shape[0], point, direction)) + LENGTH / 2)
        span = sum((b - a) * d for a, b, d in zip(shape[0], shape[-1], direction))
        if 0 < distance < span:
            return lane, distance / span * float(lane.get("length"))
    raise ValueError("the SUMO journey endpoint has no straight access lane")


def _write_ego(folder, route, depart, branch_lane, start_stop):
    root = ET.Element("routes")
    ET.SubElement(root, "vType", id=EGO_ID, length=str(LENGTH), width=str(WIDTH), maxSpeed="6",
                  speedFactor="normc(1,0,1,1)", accel="1", decel="1", emergencyDecel="1.3", apparentDecel="1.3",
                  tau="1.5", minGap="2.5", sigma="0")
    car = ET.SubElement(root, "vehicle", id=EGO_ID, type=EGO_ID, depart=str(depart),
                        departPos="base" if route[0].startswith("in_") else str(LENGTH / 2), departSpeed="0")
    ET.SubElement(car, "route", edges=" ".join(route))
    if start_stop is not None:
        lane, position = start_stop
        ET.SubElement(car, "stop", lane=lane.get("id"), endPos=str(position), duration="0.2")
    stop = float(branch_lane.get("length")) - 0.2
    ET.SubElement(car, "stop", lane=branch_lane.get("id"), endPos=str(stop), until=str(depart + 2 * SIMULATION_LIMIT))
    ET.ElementTree(root).write(folder / "ego.rou.xml", encoding="utf-8", xml_declaration=True)
    return stop


def _choose(snapshot_path, output, route, resume, end_stop):
    with gzip.open(snapshot_path, "rb") as handle:
        snapshot = ET.parse(handle)
    ego = snapshot.find(f"vehicle[@id='{EGO_ID}']")
    stop = next((stop for stop in ego.findall("stop") if stop.get("ended") is None), None) if ego is not None else None
    if stop is None:
        raise ValueError("SUMO did not checkpoint the stopped ego vehicle at the branch")
    definition = snapshot.find(f"route[@id='{ego.get('route')}']")
    definition.set("edges", " ".join(route))
    # SUMO writes the time remaining on an active stop separately from the
    # stop's scheduled end. Release the ego while preserving the rest of the
    # saved state, including traffic, RNG and queued insertions.
    state = ego.get("state").split()
    remaining_ms = round((float(stop.get("until")) - resume + 1 / NATIVE_RATE) * 1000)
    if len(state) < 10 or state[7] != "1" or state[8] != str(remaining_ms):
        raise ValueError("unsupported SUMO vehicle state for a stopped vehicle")
    state[8] = "0"
    ego.set("state", " ".join(state))
    stop.set("until", str(resume))
    lane, position = end_stop
    ET.SubElement(ego, "stop", lane=lane.get("id"), endPos=str(position), duration="1")
    snapshot.write(output, encoding="utf-8", xml_declaration=True)


def _stopped_at(ego, lane, position):
    return (ego is not None and ego.get("lane") == lane.get("id")
            and float(ego.get("speed")) == 0.0
            and abs(float(ego.get("pos")) - position) <= 0.035)


def _checkpoint(folder, tick):
    return folder / f"state_{tick / NATIVE_RATE:.3f}.xml.gz"


def _ceil_tick(seconds):
    return math.ceil(seconds * NATIVE_RATE - 1e-9)


def _slot_ticks(natural, trigger, duration, step):
    """Schedule releases on the native clock and coalesce unavailable choices."""
    earliest = trigger + CHOICE_LEAD_SECONDS
    first = max(natural, _ceil_tick(earliest))
    last = max(first, _ceil_tick(earliest + duration))
    if step * NATIVE_RATE < 1:
        # Consecutive proposed deadlines are less than one tick apart, so
        # quantization visits every tick between the first and the last.
        return list(range(first, last + 1))
    intermediate = (_ceil_tick(earliest + i * step) for i in range(1, math.ceil(duration / step)))
    return sorted({first, last, *(tick for tick in intermediate if tick > first)})


def simulate_rides(sumo, folder, *, routes, nodes, labels, origin, destinations, branch_node, seed,
                   trigger_seconds, geometry, default_option, decision_seconds=30, decision_step=10,
                   rate=5, warmup=150):
    """Simulate one holding run and continue each option from every release checkpoint."""
    last_release = trigger_seconds + decision_seconds + CHOICE_LEAD_SECONDS
    if last_release >= SIMULATION_LIMIT - 1 / NATIVE_RATE:
        raise ValueError("the requested decision window exceeds the SUMO branch search window")
    version = subprocess.run([sumo, "--version"], check=True, capture_output=True, text=True).stdout
    release = re.search(r"\bsumo (?:sumo )?(\d+\S*)", version, re.IGNORECASE)
    if not release:
        raise ValueError("could not read the SUMO version")
    net = ET.parse(folder / "district.net.xml")
    common = [edges[0] for edges in takewhile(lambda edges: len(set(edges)) == 1, zip(*routes))]
    if not common or all(len(route) == len(common) for route in routes):
        raise ValueError("the options need a shared approach and distinct continuations at the branch")
    branch_lane = _lane(net, common[-1])
    initial_route = routes[default_option]
    start_stop = (_endpoint_stop(net, *initial_route[:2], origin) if initial_route[0].startswith("in_") else None)
    stop = _write_ego(folder, initial_route, warmup, branch_lane, start_stop)
    branch_distance = _branch_distance(branch_lane, stop, geometry[default_option])
    start_direction = _heading(_lane(net, initial_route[0]))
    search_end = warmup + SIMULATION_LIMIT
    save_start = round(warmup * NATIVE_RATE) + _ceil_tick(trigger_seconds + CHOICE_LEAD_SECONDS)
    save_times = ",".join(f"{tick / NATIVE_RATE:.3f}" for tick in range(save_start, round(search_end * NATIVE_RATE)))
    start = held_from = None
    release_ticks, resumes = [], []
    prefix = []
    with _run(sumo, folder, seed, "--route-files", "district.rou.xml,ego.rou.xml",
              "--end", str(search_end), "--route-steps", "0", "--save-state.rng", "--save-state.precision", "16",
              "--save-state.times", save_times, "--save-state.prefix", "state", "--save-state.suffix", ".xml.gz",
              "--device.fcd.begin", str(warmup)) as observations:
        for tick, frame, ego in observations:
            # SUMO checkpoints are written at the beginning of the step;
            # each FCD frame describes the end of that same step.
            if release_ticks and tick == start + release_ticks[len(resumes)] + 1:
                resumes.append(tick)
                if len(resumes) == len(release_ticks):
                    break
            elif tick >= save_start:
                # The already-observed state is too early. Retain only the
                # checkpoints ahead of the FCD reader and the chosen fork.
                _checkpoint(folder, tick).unlink(missing_ok=True)
            car = frame.get(EGO_ID)
            at_start = (_stopped_at(ego, *start_stop) if start_stop is not None else
                        car is not None and _forward(origin, start_direction, car) >= -0.15)
            if start is None and at_start:
                start = tick
            if start is not None:
                if car is None:
                    raise ValueError("SUMO lost the ego vehicle before the branch")
                prefix.append(frame)
                if held_from is None and _stopped_at(ego, branch_lane, stop):
                    held_from = tick - start
                    release_ticks = _slot_ticks(held_from, trigger_seconds, decision_seconds, decision_step)
    if not release_ticks or len(resumes) != len(release_ticks):
        raise ValueError("the ego vehicle did not make its branch release slots within the SUMO recording window")

    rides = []
    payload_size = 0
    end_stops = [_endpoint_stop(net, *route[-2:], target) for route, target in zip(routes, destinations)]
    for slot, (release_tick, resume) in enumerate(zip(release_ticks, resumes)):
        shared_state = _checkpoint(folder, resume)
        resume_seconds = resume / NATIVE_RATE
        for option, (route, path, label, end_stop) in enumerate(zip(routes, nodes, labels, end_stops)):
            snapshot = "option.xml"
            _choose(shared_state, folder / snapshot, route, resume_seconds, end_stop)
            suffix = []
            with _run(sumo, folder, seed, "--begin", str(resume_seconds), "--end", str(resume_seconds + SIMULATION_LIMIT),
                      "--load-state", snapshot) as observations:
                for tick, frame, ego in observations:
                    if tick != resume + len(suffix) or EGO_ID not in frame:
                        raise ValueError(f"SUMO lost the ego vehicle before option {option}'s stop")
                    suffix.append(frame)
                    if _stopped_at(ego, *end_stop):
                        break
                else:
                    raise ValueError(f"the ego vehicle did not arrive at option {option}'s stop within the SUMO recording window")
            frames = prefix[:release_tick + 1] + suffix
            ride = _ride(option, slot, label, path, frames, geometry[option], release_tick, branch_distance, rate)
            payload_size += len(json.dumps(ride, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8"))
            check_recording_size(payload_size)
            rides.append(ride)
        shared_state.unlink()
    slots = [
        {"decide_by": round(tick / NATIVE_RATE - CHOICE_LEAD_SECONDS, 2),
         "time": round(tick / NATIVE_RATE, 2)}
        for tick in release_ticks
    ]
    branch_info = {"node": branch_node, "trigger": round(trigger_seconds, 2), "default": default_option, "slots": slots}
    hold_seconds = [round((tick - held_from) / NATIVE_RATE, 2) for tick in release_ticks]
    return f"SUMO {release[1]}", branch_info, rides, hold_seconds
